package app.models;

import java.sql.Time;
import java.time.LocalDate;

/**
 * Modelo HorarioProgramado: representa un horario (entrada/salida) programado para un funcionario.
 */

public class HorarioProgramado {
	
	// Atributos
    private int id;
    private int idFuncionario;
    private String nombreFuncionario; // para mostrar en tablas (JOIN)
    private String diaSemana;
    private Time horaEntrada;
    private Time horaSalida;
    private boolean esExcepcion;
    private LocalDate fechaExcepcion;

    /**
     * Los getters y los setters otra vez
     * */

    // ID
    public int getId() {
        return id; }
    public void setId(int id) {
        this.id = id; }

    // Funcionario
    public int getIdFuncionario() {
        return idFuncionario; }
    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario; }

    // Nomreb del funcionario
    public String getNombreFuncionario() {
        return nombreFuncionario; }
    public void setNombreFuncionario(String nombreFuncionario) {
        this.nombreFuncionario = nombreFuncionario; }

    // Dia de la semana
    public String getDiaSemana() {
        return diaSemana; }
    public void setDiaSemana(String diaSemana) {
        this.diaSemana = diaSemana; }

    // Hora de la entrada
    public Time getHoraEntrada() {
        return horaEntrada; }
    public void setHoraEntrada(Time horaEntrada) {
        this.horaEntrada = horaEntrada; }

    // Hora de la salida
    public Time getHoraSalida() {
        return horaSalida; }
    public void setHoraSalida(Time horaSalida) {
        this.horaSalida = horaSalida; }

    // Un buleano si es una excepcion
    public boolean isEsExcepcion() {
        return esExcepcion; }
    public void setEsExcepcion(boolean esExcepcion) {
        this.esExcepcion = esExcepcion; }

    // Fecha excepcion
    public LocalDate getFechaExcepcion() {
        return fechaExcepcion; }
    public void setFechaExcepcion(LocalDate fechaExcepcion) {
        this.fechaExcepcion = fechaExcepcion; }

}