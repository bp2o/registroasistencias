package app.views;

import javax.swing.*;
import java.awt.*;

/**
 * RegisterView: formulario de registro para nuevos funcionarios (solo accesible por administradores).
 */

public class RegisterView extends JFrame {

	// YA
    public JTextField txtNombre = new JTextField(25);
    public JTextField txtApellido = new JTextField(25);
    public JTextField txtCorreo = new JTextField(25);
    public JPasswordField txtPassword = new JPasswordField(25);
    public JPasswordField txtConfirmPassword = new JPasswordField(25);
    public JTextField txtTelefono = new JTextField(25);
    public JComboBox<String> cbDepartamento = new JComboBox<>();
    public JCheckBox chkEsAdmin = new JCheckBox("Este funcionario sera administrador?");
    public JButton btnRegistrar = new JButton("Registrar");
    public JButton btnVolver = new JButton("Volver al Dashboard");
    public JLabel lblStatus = new JLabel(" ");

    public RegisterView() {
    	setResizable(false);
        setTitle("Sistema de Asistencia 0.1.7 - Register");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(450, 550);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Campos del formulario

        // Nombre
        panel.add(new JLabel("Nombre:"));
        panel.add(txtNombre);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        // Apellido
        panel.add(new JLabel("Apellido:"));
        panel.add(txtApellido);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        // Correo
        panel.add(new JLabel("Correo electronico:"));
        panel.add(txtCorreo);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        // Contrasenha macaco kkkkkkk
        panel.add(new JLabel("Contrasena:"));
        panel.add(txtPassword);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        // Confirmao contrasenha manito
        panel.add(new JLabel("Confirmar contrasena:"));
        panel.add(txtConfirmPassword);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        // Hector El Father - El Telefono
        panel.add(new JLabel("Telofono:"));
        panel.add(txtTelefono);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        // Departamento
        panel.add(new JLabel("Departamento:"));
        String[] departamentos = {"RRHH", "Contabilidad", "TI", "Logistica"};
        for (String depto : departamentos) {
            cbDepartamento.addItem(depto);
        }
        panel.add(cbDepartamento);
        panel.add(Box.createRigidArea(new Dimension(0,15)));

        // Checkbox: es admin?
        chkEsAdmin.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(chkEsAdmin);
        panel.add(Box.createRigidArea(new Dimension(0,15)));

        // Botones
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnRegistrar);
        panelBotones.add(btnVolver);
        panel.add(panelBotones);

        // Status label
        panel.add(Box.createRigidArea(new Dimension(0,10)));
        lblStatus.setForeground(Color.DARK_GRAY);
        panel.add(lblStatus);

        // 67
        getContentPane().add(panel);
    }
}