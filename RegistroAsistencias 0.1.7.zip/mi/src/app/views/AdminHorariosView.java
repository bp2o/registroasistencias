package app.views;

import app.models.HorarioProgramado;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * AdminHorariosView: muestra una tabla con todos los horarios y permite CRUD básico.
 * Incluye columna con el nombre del funcionario (quien inició sesión en el registro).
 */

public class AdminHorariosView extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    public JButton btnAgregar = new JButton("Agregar");
    public JButton btnEditar = new JButton("Editar");
    public JButton btnEliminar = new JButton("Eliminar");
    public JButton btnVolver = new JButton("Volver al Dashboard");

    public AdminHorariosView() {
        setTitle("Gestionar Horarios");
        setSize(800, 400);
        setLocationRelativeTo(null);

        model = new DefaultTableModel(new Object[]{"ID","Funcionario","Dia","Entrada","Salida","Excepcion","Fecha Excepcion"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);


        JPanel buttons = new JPanel();
        buttons.add(btnAgregar); buttons.add(btnEditar); buttons.add(btnEliminar); buttons.add(btnVolver);
        add(buttons, BorderLayout.SOUTH);
    }

    /**
     * Carga la lista de horarios en la tabla.
     */

    public void loadData(List<HorarioProgramado> horarios) {
        model.setRowCount(0);
        for (HorarioProgramado h : horarios) {
            model.addRow(new Object[]{h.getId(), h.getNombreFuncionario(), h.getDiaSemana(), h.getHoraEntrada(), h.getHoraSalida(), h.isEsExcepcion(), h.getFechaExcepcion()});
        }
    }

    public int getSelectedId() {
        int r = table.getSelectedRow();
        if (r == -1) return -1;
        return (int) model.getValueAt(r, 0);
    }
}