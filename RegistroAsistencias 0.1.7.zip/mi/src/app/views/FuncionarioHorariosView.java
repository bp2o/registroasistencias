package app.views;

import app.models.HorarioProgramado;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * FuncionarioHorariosView: permite al funcionario ver sus horarios (solo lectura) y volver.
 */

public class FuncionarioHorariosView extends JFrame {
	
	// Atrib- ya me canse de documentar profe, por fa no me baje puntos por eso, tengo tendinitis
    private JTable table;
    private DefaultTableModel model;
    public JButton btnVolver = new JButton("Volver");


    public FuncionarioHorariosView() {
        setTitle("Mis Horarios");
        setSize(700, 350);
        setLocationRelativeTo(null);


        model = new DefaultTableModel(new Object[]{"ID","Dia","Entrada","Salida","Excepcion","Fecha Excepcion"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);


        JPanel p = new JPanel(); p.add(btnVolver);
        add(p, BorderLayout.SOUTH);
    }

    // Cargar los horarios
    public void loadData(List<HorarioProgramado> horarios) {
        model.setRowCount(0);
        for (HorarioProgramado h : horarios) {
            model.addRow(new Object[]{h.getId(), h.getDiaSemana(), h.getHoraEntrada(), h.getHoraSalida(), h.isEsExcepcion(), h.getFechaExcepcion()});
        }
    }
}