package app.views;

import java.awt.*;
import javax.swing.*;

// Codigo implementado en la clase   0.1.6

public class FuncionarioVerJustificacionView extends JFrame {
	
	// Empezando la construccion de la intefaz
	public JTable tabla;
	public JButton btnVolver = new JButton("Volver");
	
	public FuncionarioVerJustificacionView() {
		setTitle("Mis justificaciones");
		setSize(700, 400);
		setLocationRelativeTo(null);
		setResizable(false);
		
		tabla = new JTable();
		JScrollPane scroll = new JScrollPane(tabla);
		
		JPanel p = new JPanel(new BorderLayout());
		p.add(scroll, BorderLayout.CENTER);
		p.add(btnVolver, BorderLayout.SOUTH);
		
		getContentPane().add(p);
	}
	
	// Metodo para cargar los datos (no lo quiero organizar)
			public void loadData(Object[][] data) {
				String[] columnas = {
						"Inicio", "Fin", "Motivo", "Estado", "Comentario Admin"
						};
				
				tabla.setModel(new javax.swing.table.DefaultTableModel(data, columnas));
			}
}