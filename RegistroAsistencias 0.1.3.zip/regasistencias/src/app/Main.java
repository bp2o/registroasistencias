package app;

import app.views.*;
import app.controllers.LoginController;
import app.controllers.RegisterController;
import app.dao.*;
import app.utils.*;

import javax.swing.*;

// Cambios hechos 0.1.3
// ALFIN ARREGLE LOS BOTONES (excepto el de crear funcionario en AdminPanel)

// Profe una nota positiva almenos o te embrujo con un labubu

public class Main {
    public static void main(String[] args) {
        UITheme.applyTheme();

        SwingUtilities.invokeLater(() -> {
            FuncionarioDAO dao = new FuncionarioDAO();

            // Si no hay funcionario con admin en la BD, se abre el panel de Register
            if (!dao.existeAdministrador()) {
                System.out.println("No existe administrador. Abriendo registro...");
                RegisterView registerView = new RegisterView();
                new RegisterController(registerView);
                registerView.btnVolver.setVisible(false); // opcional: ocultar si es modo instalación
                registerView.setVisible(true);
            } else {

                // Pues si hay admin, se abre el login lol
            	System.out.println("Administrador encontrado. Mostrando login...");
                LoginView loginView = new LoginView();
                new LoginController(loginView);
                loginView.setVisible(true);
            }



            // Y eso es everything profe, al menos un 4.0 la nota, o te comento un "-rep" en tu Steam
            // y no te lo firmo :(

            // Con toda fe que funcione bien este programa

            // Mi reaccion si el programa tira errores
            // https://media.tenor.com/hC63Ng2wcbYAAAAM/crying-man.gif
        });
    }
}