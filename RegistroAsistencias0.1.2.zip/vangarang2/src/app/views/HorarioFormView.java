package app.views;

import app.models.HorarioProgramado;
import app.dao.FuncionarioDAO;

import javax.swing.*;
import java.awt.*;
import java.sql.Time;
import java.util.HashMap;
import java.util.Map;

/**
 * Formulario para agregar o editar horarios
 */
public class HorarioFormView extends JDialog {
    public JComboBox<String> cbFuncionario = new JComboBox<>();
    public JComboBox<String> cbDiaSemana = new JComboBox<>();
    public JSpinner spHoraEntrada = new JSpinner(new SpinnerDateModel());
    public JSpinner spHoraSalida = new JSpinner(new SpinnerDateModel());
    public JCheckBox chkExcepcion = new JCheckBox("Es excepción (horario especial)");
    public JSpinner spFechaExcepcion = new JSpinner(new SpinnerDateModel());
    public JButton btnGuardar = new JButton("Guardar");
    public JButton btnCancelar = new JButton("Cancelar");

    private Map<String, Integer> funcionariosMap = new HashMap<>();
    private boolean isEditMode = false;
    private HorarioProgramado horarioEdit;

    public HorarioFormView(JFrame parent, boolean isEditMode, HorarioProgramado horario) {
        super(parent, true);
        this.isEditMode = isEditMode;
        this.horarioEdit = horario;

        setTitle(isEditMode ? "Editar Horario" : "Agregar Horario");
        setSize(500, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        initComponents();
        loadFuncionarios();
        if (isEditMode && horario != null) {
            loadHorarioData();
        }

        pack();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Configurar spinners de hora
        JSpinner.DateEditor editorEntrada = new JSpinner.DateEditor(spHoraEntrada, "HH:mm");
        spHoraEntrada.setEditor(editorEntrada);
        spHoraEntrada.setValue(new java.util.Date());

        JSpinner.DateEditor editorSalida = new JSpinner.DateEditor(spHoraSalida, "HH:mm");
        spHoraSalida.setEditor(editorSalida);
        spHoraSalida.setValue(new java.util.Date());

        // Configurar spinner de fecha excepción
        spFechaExcepcion.setModel(new SpinnerDateModel());
        JSpinner.DateEditor editorFecha = new JSpinner.DateEditor(spFechaExcepcion, "dd/MM/yyyy");
        spFechaExcepcion.setEditor(editorFecha);
        spFechaExcepcion.setValue(new java.util.Date());
        spFechaExcepcion.setEnabled(false);

        // Días de la semana (deben coincidir con el ENUM de la BD)
        String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        for (String dia : dias) {
            cbDiaSemana.addItem(dia);
        }

        // Layout
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Funcionario:"), gbc);

        gbc.gridx = 1;
        panel.add(cbFuncionario, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Día de la semana:"), gbc);

        gbc.gridx = 1;
        panel.add(cbDiaSemana, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Hora entrada:"), gbc);

        gbc.gridx = 1;
        panel.add(spHoraEntrada, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Hora salida:"), gbc);

        gbc.gridx = 1;
        panel.add(spHoraSalida, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 2;
        panel.add(chkExcepcion, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Fecha excepción:"), gbc);

        gbc.gridx = 1;
        panel.add(spFechaExcepcion, gbc);

        // Listeners
        chkExcepcion.addActionListener(e -> {
            spFechaExcepcion.setEnabled(chkExcepcion.isSelected());
            cbDiaSemana.setEnabled(!chkExcepcion.isSelected());
        });

        add(panel, BorderLayout.CENTER);

        // Botones
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void loadFuncionarios() {
        try {
            FuncionarioDAO funcDAO = new FuncionarioDAO();
            Map<String, Integer> funcionarios = funcDAO.getFuncionariosActivos();
            funcionariosMap.clear();
            cbFuncionario.removeAllItems();

            if (funcionarios.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "No hay funcionarios activos en el sistema.\nDebe crear funcionarios primero.",
                        "Sin datos",
                        JOptionPane.WARNING_MESSAGE);
                cbFuncionario.addItem("-- No hay funcionarios --");
            } else {
                funcionariosMap.putAll(funcionarios);

                // Agregar combres al ComboBox creo
                for (String nombre : funcionariosMap.keySet()) {
                    cbFuncionario.addItem(nombre);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error al cargar funcionarios: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadHorarioData() {
        if (horarioEdit == null) return;

        // Buscar y seleccionar el funcionario
        for (String item : funcionariosMap.keySet()) {
            if (item.contains(horarioEdit.getNombreFuncionario())) {
                cbFuncionario.setSelectedItem(item);
                break;
            }
        }

        cbDiaSemana.setSelectedItem(horarioEdit.getDiaSemana());

        // Configurar horas
        if (horarioEdit.getHoraEntrada() != null) {
            java.util.Date horaEntrada = new java.util.Date(horarioEdit.getHoraEntrada().getTime());
            spHoraEntrada.setValue(horaEntrada);
        }

        if (horarioEdit.getHoraSalida() != null) {
            java.util.Date horaSalida = new java.util.Date(horarioEdit.getHoraSalida().getTime());
            spHoraSalida.setValue(horaSalida);
        }

        // Excepciones
        chkExcepcion.setSelected(horarioEdit.isEsExcepcion());
        spFechaExcepcion.setEnabled(horarioEdit.isEsExcepcion());

        if (horarioEdit.getFechaExcepcion() != null) {
            java.util.Date fechaExcep = java.sql.Date.valueOf(horarioEdit.getFechaExcepcion());
            spFechaExcepcion.setValue(fechaExcep);
        }
    }

    public HorarioProgramado getHorario() {
        HorarioProgramado horario = new HorarioProgramado();

        // Obtener ID del funcionario seleccionado
        String selected = (String) cbFuncionario.getSelectedItem();
        if (selected != null && funcionariosMap.containsKey(selected)) {
            horario.setIdFuncionario(funcionariosMap.get(selected));
        }

        horario.setDiaSemana((String) cbDiaSemana.getSelectedItem());

        // Convertir horas
        java.util.Date entrada = (java.util.Date) spHoraEntrada.getValue();
        horario.setHoraEntrada(new Time(entrada.getTime()));

        java.util.Date salida = (java.util.Date) spHoraSalida.getValue();
        horario.setHoraSalida(new Time(salida.getTime()));

        // Excepcion
        horario.setEsExcepcion(chkExcepcion.isSelected());

        if (chkExcepcion.isSelected()) {
            java.util.Date fechaExcep = (java.util.Date) spFechaExcepcion.getValue();
            horario.setFechaExcepcion(new java.sql.Date(fechaExcep.getTime()).toLocalDate());
        }

        if (isEditMode && horarioEdit != null) {
            horario.setId(horarioEdit.getId());
        }

        return horario;
    }
}