package app.views;

import javax.swing.*;
import java.awt.*;

/**
 * FuncionarioDashboardView: panel principal para funcionarios.
 */

public class FuncionarioDashboardView extends JFrame {
    public JButton btnVerHorarios = new JButton("Ver mis horarios");
    public JButton btnCrearJustificacion = new JButton("Crear justificación");
    public JButton btnCerrarSesion = new JButton("Cerrar sesión");
    public JLabel lblUsuario = new JLabel();

    public FuncionarioDashboardView(String nombreUsuario) {
        setTitle("Dashboard - Funcionario");
        setSize(600, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);


        lblUsuario.setText("Conectado: " + nombreUsuario);


        JPanel panel = new JPanel(new GridLayout(4,1,10,10));
        panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        panel.add(lblUsuario);
        panel.add(btnVerHorarios);
        panel.add(btnCrearJustificacion);
        panel.add(btnCerrarSesion);
        add(panel);
    }
}