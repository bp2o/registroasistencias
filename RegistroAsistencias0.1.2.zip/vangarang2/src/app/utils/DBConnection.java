package app.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * DBConnection: administra una única conexión JDBC a la base de datos MySQL.
 * Edita la URL, usuario y contraseña según tu entorno.
 */

public class DBConnection {
    private static Connection conn;

    // === EDITAR ESTOS DATOS SEGÚN EL SERVIDOR ======= //

    private static final String URL = "jdbc:mysql://localhost:33065/empresa_asistencia2"; // Editar tu url
    private static final String USER = "root"; // Editar tu user
    private static final String PASS = ""; // Editar tu contraseña

    // ================================================ //

    private static Connection connection;

    /**
     * Inicializa la conexión
     */

    public static Connection getConnection() throws SQLException {
        // Si no existe o est� cerrada, crear una nueva conexi�n
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(URL, USER, PASS);
        }
        return connection;
    }

    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}