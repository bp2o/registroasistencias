package app.models;

/**
 * Modelo Funcionario
 */
public class Funcionario {
    private int id;
    private String nombre;
    private String apellido;
    private String correo;
    private String passwordHash; // puede contener el hash o la contrase�a en texto (DAO decidir�)
    private String telefono;
    private String departamento;
    private boolean esAdmin; // NUEVO
    private boolean activo;
    private java.sql.Date fechaContratacion;

    public Funcionario() {
        this.activo = true;
        this.esAdmin = false;
    }

    // Getters y setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPasswordHash() {
        return passwordHash;
    }
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDepartamento() {
        return departamento;
    }
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public boolean isEsAdmin() {
        return esAdmin;
    }
    public void setEsAdmin(boolean esAdmin) {
        this.esAdmin = esAdmin;
    }

    public boolean isActivo() {
        return activo;
    }
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public java.sql.Date getFechaContratacion() {
        return fechaContratacion;
    }
    public void setFechaContratacion(java.sql.Date fechaContratacion) {
        this.fechaContratacion = fechaContratacion;
    }

    // Utilitario
    public String getNombreCompleto() {
        String n = nombre == null ? "" : nombre.trim();
        String a = apellido == null ? "" : apellido.trim();
        return (n + " " + a).trim();
    }

    @Override
    public String toString() {
        return "Funcionario{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", correo='" + correo + '\'' +
                ", telefono='" + telefono + '\'' +
                ", departamento='" + departamento + '\'' +
                ", esAdmin=" + esAdmin +
                ", activo=" + activo +
                '}';
    }
}