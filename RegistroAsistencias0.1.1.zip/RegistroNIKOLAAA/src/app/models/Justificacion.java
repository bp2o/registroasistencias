package app.models;

import java.time.LocalDate;

/**
 * Modelo Justificacion: representa una justificación enviada por un funcionario.
 */

public class Justificacion {
    private int id;
    private int idFuncionario;
    private String nombreFuncionario; // para mostrar en tablas
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private String motivo;
    private String estado;
    private Integer idAdminAprobador;
    private LocalDate fechaAprobacion;
    private String comentarioAdmin;

    // getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getIdFuncionario() { return idFuncionario; }
    public void setIdFuncionario(int idFuncionario) { this.idFuncionario = idFuncionario; }
    public String getNombreFuncionario() { return nombreFuncionario; }
    public void setNombreFuncionario(String nombreFuncionario) { this.nombreFuncionario = nombreFuncionario; }
    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }
    public LocalDate getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }
    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public Integer getIdAdminAprobador() { return idAdminAprobador; }
    public void setIdAdminAprobador(Integer idAdminAprobador) { this.idAdminAprobador = idAdminAprobador; }
    public LocalDate getFechaAprobacion() { return fechaAprobacion; }
    public void setFechaAprobacion(LocalDate fechaAprobacion) { this.fechaAprobacion = fechaAprobacion; }
    public String getComentarioAdmin() { return comentarioAdmin; }
    public void setComentarioAdmin(String comentarioAdmin) { this.comentarioAdmin = comentarioAdmin; }
}