package app.models;

import java.sql.Time;
import java.time.LocalDate;

/**
 * Modelo HorarioProgramado: representa un horario (entrada/salida) programado para un funcionario.
 */

public class HorarioProgramado {
    private int id;
    private int idFuncionario;
    private String nombreFuncionario; // para mostrar en tablas (JOIN)
    private String diaSemana;
    private Time horaEntrada;
    private Time horaSalida;
    private boolean esExcepcion;
    private LocalDate fechaExcepcion;

    // getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getIdFuncionario() { return idFuncionario; }
    public void setIdFuncionario(int idFuncionario) { this.idFuncionario = idFuncionario; }
    public String getNombreFuncionario() { return nombreFuncionario; }
    public void setNombreFuncionario(String nombreFuncionario) { this.nombreFuncionario = nombreFuncionario; }
    public String getDiaSemana() { return diaSemana; }
    public void setDiaSemana(String diaSemana) { this.diaSemana = diaSemana; }
    public Time getHoraEntrada() { return horaEntrada; }
    public void setHoraEntrada(Time horaEntrada) { this.horaEntrada = horaEntrada; }
    public Time getHoraSalida() { return horaSalida; }
    public void setHoraSalida(Time horaSalida) { this.horaSalida = horaSalida; }
    public boolean isEsExcepcion() { return esExcepcion; }
    public void setEsExcepcion(boolean esExcepcion) { this.esExcepcion = esExcepcion; }
    public LocalDate getFechaExcepcion() { return fechaExcepcion; }
    public void setFechaExcepcion(LocalDate fechaExcepcion) { this.fechaExcepcion = fechaExcepcion; }
}