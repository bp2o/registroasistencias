package app.controllers;

import app.dao.FuncionarioDAO;
import app.models.Funcionario;
import app.views.AdminDashboardView;
import app.views.FuncionarioDashboardView;
import app.views.LoginView;

import javax.swing.*;

/**
 * LoginController: controla la autenticaci�n de funcionarios.
 */
public class LoginController {
    private final LoginView view;
    private final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

    public LoginController(LoginView view) {
        this.view = view;

        // Evento de login
        this.view.btnLogin.addActionListener(e -> login());
    }

    /**
     * Intenta autenticar al funcionario.
     */
    private void login() {
        String correo = view.txtEmail.getText().trim();
        char[] password = view.txtPassword.getPassword();

        if (correo.isEmpty() || password.length == 0) {
            view.lblStatus.setText("Por favor, ingresa tus credenciales.");
            return;
        }

        Funcionario funcionario = funcionarioDAO.authenticate(correo, password);
        if (funcionario != null) {
            view.dispose();

            if (funcionario.isEsAdmin()) {
                abrirDashboardAdmin(funcionario);
            } else {
                abrirDashboardFuncionario(funcionario);
            }
        } else {
            view.lblStatus.setText("Credenciales incorrectas o usuario inactivo.");
        }
    }

    /**
     * Abre el dashboard del administrador.
     */
    private void abrirDashboardAdmin(Funcionario admin) {
        AdminDashboardView adminDashboard = new AdminDashboardView(admin.getNombre() + " " + admin.getApellido());

        adminDashboard.btnCerrarSesion.addActionListener(e -> logout(adminDashboard));
        adminDashboard.btnHorarios.addActionListener(e -> openAdminHorarios(adminDashboard, admin));
        adminDashboard.btnJustificaciones.addActionListener(e -> openAdminJustificaciones(adminDashboard, admin));

        adminDashboard.setVisible(true);
    }

    /**
     * Abre el dashboard del funcionario normal.
     */
    private void abrirDashboardFuncionario(Funcionario func) {
        FuncionarioDashboardView funcDashboard = new FuncionarioDashboardView(func.getNombre() + " " + func.getApellido());
        funcDashboard.btnCerrarSesion.addActionListener(e -> logout(funcDashboard));
        funcDashboard.btnVerHorarios.addActionListener(e -> openFuncionarioHorarios(funcDashboard, func));
        funcDashboard.btnCrearJustificacion.addActionListener(e -> openCrearJustificacion(funcDashboard, func));
        funcDashboard.setVisible(true);
    }

    /**
     * Cierra sesi�n y vuelve al login.
     */
    private void logout(JFrame dash) {
        dash.dispose();
        LoginView lv = new LoginView();
        new LoginController(lv);
        lv.setVisible(true);
    }

    // -------- ADMIN helpers (reutiliza tu l�gica previa) --------
    private void openAdminHorarios(JFrame parent, Funcionario admin) {
        // Aqu� puedes invocar AdminHorariosView, etc.
    }

    private void openAdminJustificaciones(JFrame parent, Funcionario admin) {
        // Aqu� puedes invocar AdminJustificacionesView, etc.
    }

    // -------- FUNCIONARIO helpers --------
    private void openFuncionarioHorarios(JFrame parent, Funcionario func) {
        // Aqu� puedes invocar FuncionarioHorariosView, etc.
    }

    private void openCrearJustificacion(JFrame parent, Funcionario func) {
        // Aqu� puedes invocar FuncionarioCrearJustificacionView, etc.
    }
}