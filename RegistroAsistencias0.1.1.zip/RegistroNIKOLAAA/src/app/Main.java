package app;

import app.controllers.LoginController;
import app.views.LoginView;
import app.utils.UITheme;

public class Main {
    public static void main(String[] args) {

        // Aplicar tema visual
        UITheme.applyTheme();

        // No inicialices la conexi�n aqu�.
        // DBConnection se gestiona autom�ticamente en los DAOs.

        // Iniciar interfaz en el hilo de Swing
        javax.swing.SwingUtilities.invokeLater(() -> {
            LoginView view = new LoginView();
            new LoginController(view);
            view.setVisible(true);
        });
    }
}
