package app;

import app.views.*;
import app.controllers.LoginController;
import app.controllers.RegisterController;
import app.dao.*;
import app.utils.*;

import javax.swing.*;

// Cambios hechos 0.1.5
// Boton de Registrar Funcionario no abria

// Faltaria implementar las funciones de justificacion
// Y si el admin aprueba o rechaza y le manda un comentario
// como el usuario puede ver si su justificacion es aprobada o rechazada?

// Funciones de la justificacion en desarrollo para la proxima actualizacion

// 25/11/2025 - Nueva clase en paquete app.views: FuncionarioVerJustificacionView.java

// Extension necesaria en JustificacionDAO.java, porque no tienen metodo para obtener 
// las justificaciones del funcionario logueado con comentario del admin.
// Agregar un public void sobre eso en LoginController.java

public class Main {
    public static void main(String[] args) {
        UITheme.applyTheme(); // Para aplicar colores

        SwingUtilities.invokeLater(() -> {
            FuncionarioDAO dao = new FuncionarioDAO();

            // Si no hay funcionario con admin en la BD, se abre el panel de Register
            if (!dao.existeAdministrador()) {
                System.out.println("No existe administrador. Abriendo registro...");
                RegisterView registerView = new RegisterView();
                new RegisterController(registerView);
                registerView.btnVolver.setVisible(false); // opcional: ocultar si es modo instalacion
                registerView.setVisible(true);
            } else {

                // Pues si hay admin, se abre el login lol
            	System.out.println("Administrador encontrado. Mostrando login...");
                LoginView loginView = new LoginView();
                new LoginController(loginView);
                loginView.setVisible(true);
            }



            // Y eso es everything profe, al menos un 4.0 la nota, o te comento un "-rep" en tu Steam
            // y no te lo firmo :(

            // Con toda fe que funcione bien este programa

            // Mi reaccion si el programa tira errores
            // https://media.tenor.com/hC63Ng2wcbYAAAAM/crying-man.gif
        });
    }
}