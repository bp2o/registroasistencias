package app.dao;

import app.models.Justificacion;
import app.utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JustificacionDAO: operaciones para listar y crear justificaciones.
 */

public class JustificacionDAO {

    /**
     * Lista todas las justificaciones (con nombre de funcionario para mostrar a admin).
     */

    public List<Justificacion> findAllWithFuncionario() {
        List<Justificacion> list = new ArrayList<>();
        String sql = "SELECT j.id_justificacion, j.id_funcionario, CONCAT(f.nombre,' ',f.apellido) AS nombre_funcionario, j.fecha_inicio, j.fecha_fin, j.motivo, j.estado, j.id_admin_aprobador, j.fecha_creacion FROM Justificacion j JOIN Funcionario f ON j.id_funcionario = f.id_funcionario";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Justificacion j = new Justificacion();
                j.setId(rs.getInt("id_justificacion"));
                j.setIdFuncionario(rs.getInt("id_funcionario"));
                j.setNombreFuncionario(rs.getString("nombre_funcionario"));
                Date fi = rs.getDate("fecha_inicio"); if (fi != null) j.setFechaInicio(fi.toLocalDate());
                Date ff = rs.getDate("fecha_fin"); if (ff != null) j.setFechaFin(ff.toLocalDate());
                j.setMotivo(rs.getString("motivo"));
                j.setEstado(rs.getString("estado"));
                list.add(j);
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        return list;
    }

    /**
     * Crea una justificación por parte de un funcionario.
     */

    public boolean create(int idFuncionario, Date inicio, Date fin, String motivo) {
        String sql = "INSERT INTO Justificacion (id_funcionario, fecha_inicio, fecha_fin, motivo, estado, fecha_creacion) VALUES (?, ?, ?, ?, 'Pendiente', NOW())";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idFuncionario);
            ps.setDate(2, inicio);
            ps.setDate(3, fin);
            ps.setString(4, motivo);
            return ps.executeUpdate() == 1;
        } catch (Exception ex) { ex.printStackTrace(); }
        return false;
    }

    /**
     * Actualiza la justificacion para el funcionario
     * */

    // 0.1.2
    public boolean updateEstado(int idJustificacion, String nuevoEstado, Integer idAdminAprobador, java.sql.Timestamp fechaAprobacion, String comentarioAdmin) {
        String sql = "UPDATE Justificacion SET estado = ?, id_admin_aprobador = ?, fecha_aprobacion = ?, comentario_admin = ? WHERE id_justificacion = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nuevoEstado);
            if (idAdminAprobador != null) ps.setInt(2, idAdminAprobador); else ps.setNull(2, Types.INTEGER);
            if (fechaAprobacion != null) ps.setTimestamp(3, fechaAprobacion); else ps.setNull(3, Types.TIMESTAMP);
            ps.setString(4, comentarioAdmin);
            ps.setInt(5, idJustificacion);
            return ps.executeUpdate() == 1;
        } catch (Exception ex) { ex.printStackTrace(); }
        return false;
    }
}