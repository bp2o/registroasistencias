package app.views;

import javax.swing.*;

public class FuncionarioVerJustificacionView {
	// Empezando a construir la intefaz grafica de eso
}