package app.dao;

import app.models.Funcionario;
import app.utils.DBConnection;
import app.utils.PasswordUtils;

import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * FuncionarioDAO
 * - insert(Funcionario f) : inserta un funcionario (y hash de password)
 * - authenticate(correo, password) : devuelve Funcionario si ok
 * - getFuncionariosActivos() : para combobox/listas
 * - existeAdministrador() : un boolean que detecte en la DB si hay admin o no
 */

public class FuncionarioDAO {

    /**
     * Inserta un funcionario en la base de datos.
     * Si el campo passwordHash del objeto contiene la password en texto plano,
     * este metodo la convertir a hash antes de insertar a la base de datos.
     *
     * @param f Funcionario con los datos (passwordHash puede ser plaintext)
     * @return true si se inserta correctamente
     */

    public boolean insert(Funcionario f) {
    	System.out.println("entry");
        // Asegurarse que correo no sea nulo
        if (f.getCorreo() == null || f.getCorreo().trim().isEmpty()) return false;

        // Preparar hash de password (si ya esta en formato hash no hay forma facil de comprobarlo,
        // asumimos que si la cadena tiene '$' (BCrypt tipico) ya esta hasheada a heuristica ligera)
        String pass = f.getPasswordHash() == null ? "" : f.getPasswordHash();
        String passwordHash;
        try {
            if (pass.contains("$") && pass.length() > 20) {
                // Podria ser un hash (heuristica), usamos tal cual
                passwordHash = pass;
            } else {
                // Se asume que viene en texto plano -> generar hash
                passwordHash = PasswordUtils.hashPassword(pass.toCharArray());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }

        String sql = "INSERT INTO Funcionario (nombre, apellido, correo, password_hash, telefono, departamento, es_admin, activo, fecha_contratacion, fecha_creacion) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, TRUE, CURDATE(), CURRENT_TIMESTAMP)";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, f.getNombre());
            ps.setString(2, f.getApellido());
            ps.setString(3, f.getCorreo());
            ps.setString(4, passwordHash);
            ps.setString(5, f.getTelefono());
            ps.setString(6, f.getDepartamento());
            ps.setBoolean(7, f.isEsAdmin());

            int affected = ps.executeUpdate();
            if (affected == 1) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        f.setId(keys.getInt(1));
                        System.out.println("creado f... ");
                    }
                }
                return true;
            }
            return false;

        } catch (SQLIntegrityConstraintViolationException ex) {
        	
            // correo duplicado, etc.
            System.err.println("[AVISO] No se puede insertar funcionario. Violacion de constraint: " + ex.getMessage());
            return false;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Autentica un funcionario por correo y contrase�a en claro (char[]).
     * Devuelve el objeto Funcionario completo (sin password) o null si falla.
     */
    public Funcionario authenticate(String correo, char[] password) {
        String sql = "SELECT id_funcionario, nombre, apellido, correo, password_hash, telefono, departamento, es_admin, activo " +
                "FROM Funcionario WHERE correo = ?";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, correo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    boolean activo = rs.getBoolean("Activo"); // ???
                    if (!activo) return null; // cuenta inactiva

                    String storedHash = rs.getString("password_hash");
                    if (storedHash == null) return null;

                    if (PasswordUtils.verifyPassword(password, storedHash)) {
                        Funcionario f = new Funcionario();
                        f.setId(rs.getInt("id_funcionario"));
                        f.setNombre(rs.getString("nombre"));
                        f.setApellido(rs.getString("apellido"));
                        f.setCorreo(rs.getString("correo"));
                        f.setTelefono(rs.getString("telefono"));
                        f.setDepartamento(rs.getString("departamento"));
                        f.setEsAdmin(rs.getBoolean("es_admin"));
                        f.setActivo(true);
                        return f;
                    }
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * Obtiene un mapa de nombreCompleto - id_funcionario para los activos (�til para comboboxes).
     */

    public Map<String, Integer> getFuncionariosActivos() {
        Map<String, Integer> funcionarios = new LinkedHashMap<>();
        String sql = "SELECT id_funcionario, nombre, apellido, departamento FROM Funcionario WHERE activo = TRUE ORDER BY nombre, apellido";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String nombreCompleto = rs.getString("nombre") + " " + rs.getString("apellido") + " - " + rs.getString("departamento");
                funcionarios.put(nombreCompleto, rs.getInt("id_funcionario"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return funcionarios;
    }

    /**
     * Metodo BOOLEAN de que detecte si hay un funcionario con admin en la base de datos
     * */

    // Woah esto es nuevo!! 0.1.2
    public boolean existeAdministrador() {
        String sql = "SELECT COUNT(*) FROM funcionario WHERE es_admin = TRUE";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}