package app;

import app.views.*;
import app.controllers.LoginController;
import app.controllers.RegisterController;
import app.dao.*;
import app.utils.*;
import java.sql.SQLException;

import javax.swing.*;

// Update 0.1.9
// Arreglado el problema de que se abre el Dashboard admin al cerrar o editar un horario

// Cambios desconocidos en la 0.1.8

// Pequeno cambio en la 0.1.7
// Un poco de organizacion en los codigos

// Cambios hechos 0.1.6
// Funcionario ahora puede ver si si justificacion es aprobada o rechazada + comentario admin
// Solucionado el error de no poder agregar horario en Miercoles y Viernes

// Lo que podemos implementar en el proyecto es:
// Que el admin pueda editar el estado si un funcionario esta inactivo en la empresa (Experimental)

// Por que implementar eso?
// Si la empresa despiden a un funcionario, el funcionario aun puede usar el sistema
// para ver sus horarios, y tal vez el ex-funcionario pueda cometer tonteras como
// hacer spam en las Justificaciones

public class Main {
    public static void main(String[] args) {
        UITheme.applyTheme(); // Para aplicar colores

        SwingUtilities.invokeLater(() -> {
        	
            // Intentar establecer conexion y mostrar estado
            try {
                DBConnection.getConnection();
            } catch (SQLException e) {
                System.err.println("Error al conectar a la BD: " + e.getMessage());
                e.printStackTrace();
                System.err.println("Comprueba: servidor MySQL en ejecución, puerto, usuario/contraseña y que el JAR del conector esté en el classpath.");
            }
            System.out.println(DBConnection.getConnectionStatusMessage());

            FuncionarioDAO funcionario = new FuncionarioDAO();
            
            // Si no hay funcionario con admin en la BD, se abre el panel de Register
            if (!funcionario.existeAdministrador()) {
                System.out.println("No existe administrador. Abriendo registro...");
                RegisterView registerView = new RegisterView();
                new RegisterController(registerView);
                
                registerView.btnVolver.setVisible(false); // opcional: ocultar si es modo instalacion
                
                registerView.setVisible(true);
            } else {

                // Pues si hay admin, se abre el login lol
            	System.out.println("Administrador encontrado. Mostrando login...");
                LoginView loginView = new LoginView();
                new LoginController(loginView);
                loginView.setVisible(true);
            }



          
            // Mi reaccion si el programa tira errores
            // https://media.tenor.com/hC63Ng2wcbYAAAAM/crying-man.gif
        });
    }
}