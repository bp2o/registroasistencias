package app.views;

import javax.swing.*;
import java.awt.*;

/**
 * FuncionarioDashboardView: panel principal para funcionarios.
 */

public class FuncionarioDashboardView extends JFrame {
	
	// Atributos
    public JButton btnVerHorarios = new JButton("Ver mis horarios");
    public JButton btnCrearJustificacion = new JButton("Ver mis justificaciones");
    public JButton btnCerrarSesion = new JButton("Cerrar sesion");
    public JLabel lblUsuario = new JLabel();

    public FuncionarioDashboardView(String nombreUsuario) {
    	setResizable(false);
        setTitle("Dashboard - Funcionario");
        setSize(600, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        lblUsuario.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblUsuario.setHorizontalAlignment(SwingConstants.CENTER);

        // Para que se muestre el usuario conectado
        lblUsuario.setText("Conectado: " + nombreUsuario);

        // Agregando panel y eso
        JPanel panel = new JPanel(new GridLayout(4,1,10,10));
        panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        panel.add(lblUsuario);
        panel.add(btnVerHorarios);
        panel.add(btnCrearJustificacion);
        panel.add(btnCerrarSesion);
        getContentPane().add(panel);
    }
}