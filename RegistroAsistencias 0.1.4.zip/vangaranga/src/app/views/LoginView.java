package app.views;

import javax.swing.*;
import java.awt.*;

/**
 * LoginView: formulario simple de inicio de sesi�n sin opci�n p�blica de registro.
 */

public class LoginView extends JFrame {

    public JTextField txtEmail = new JTextField(25);
    public JPasswordField txtPassword = new JPasswordField(25);
    public JButton btnLogin = new JButton("Iniciar sesion");
    public JLabel lblStatus = new JLabel(" ");

    public LoginView() {
    	setResizable(false);
        setTitle("Sistema de Asistencia - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 250);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Correo:"));
        panel.add(txtEmail);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(new JLabel("Contrasena:"));
        panel.add(txtPassword);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        JPanel panelLogin = new JPanel();
        panelLogin.add(btnLogin);
        panel.add(panelLogin);

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(lblStatus, BorderLayout.SOUTH);
    }
}