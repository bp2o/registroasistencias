package app.utils;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * UITheme: centraliza colores y estilos para poder modificarlos fácilmente.
 */

public class UITheme {

    // Colores editables
    public static Color BACKGROUND = new Color(75, 75, 75);
    public static Color PANEL = new Color(75, 75, 75);
    public static Color PRIMARY = new Color(255, 165, 0);
    public static Color TEXT = new Color(255, 255, 255);

    /**
     * Aplica valores por defecto al UIManager para que componentes Swing usen la paleta.
     */

    public static void applyTheme() {
        UIManager.put("Panel.background", BACKGROUND);
        UIManager.put("Button.background", PRIMARY);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Label.foreground", TEXT);
        UIManager.put("TextField.background", Color.WHITE);
    }
}