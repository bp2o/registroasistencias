package app.views;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;

/**
 * FuncionarioCrearJustificacionView: formulario para que el funcionario cree una justificación.
 */

public class FuncionarioCrearJustificacionView extends JFrame {
	
	// Atributos supongo..
    public JSpinner spFechaInicio = new JSpinner(new SpinnerDateModel());
    public JSpinner spFechaFin = new JSpinner(new SpinnerDateModel());
    public JTextArea taMotivo = new JTextArea(4,30);
    public JButton btnCrear = new JButton("Crear Justificacion");
    public JButton btnVolver = new JButton("Volver");
    public final JButton btnVerJustificacion = new JButton("Ver Justificacion"); // Nuevo 0.1.6

    public FuncionarioCrearJustificacionView() {
        setTitle("Mis justificaciones");
        setSize(600, 300);
        setLocationRelativeTo(null);

        // Panel lel
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // El texto ese
        p.add(new JLabel("Fecha inicio:")); p.add(spFechaInicio);
        p.add(new JLabel("Fecha fin:")); p.add(spFechaFin);
        p.add(new JLabel("Motivo:")); p.add(new JScrollPane(taMotivo));
        
        // Agregando panel y botoncitos
        JPanel btns = new JPanel();
        btns.add(btnCrear); 
        btns.add(btnVerJustificacion); // Nuevo 0.1.6
        btns.add(btnVolver);
        
        // Tu quien eres?
        p.add(btns);
        getContentPane().add(p);
    }
}