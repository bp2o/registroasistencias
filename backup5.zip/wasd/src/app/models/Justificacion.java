package app.models;

import java.time.LocalDate;

/**
 * Modelo Justificacion: representa una justificacion enviada por un funcionario.
 */

public class Justificacion {
	
	// Atributos
    private int id;
    private int idFuncionario;
    private String nombreFuncionario; // para mostrar en tablas
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private String motivo;
    private String estado;
    private Integer idAdminAprobador;
    private LocalDate fechaAprobacion;
    private String comentarioAdmin;

    /**
     * Los getters y los setters wasd
     * */

    // ID
    public int getId() {
        return id; }
    public void setId(int id) {
        this.id = id; }

    // ID Funcionario no se
    public int getIdFuncionario() {
        return idFuncionario; }
    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario; }

    // Nombre Funcionario
    public String getNombreFuncionario() {
        return nombreFuncionario; }
    public void setNombreFuncionario(String nombreFuncionario) {
        this.nombreFuncionario = nombreFuncionario; }

    // Fecha Inicio
    public LocalDate getFechaInicio() {
        return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio; }

    // Fecha Fin
    public LocalDate getFechaFin() {
        return fechaFin; }
    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin; }

    // Motivo. por que. como que por que mono con-
    public String getMotivo() {
        return motivo; }
    public void setMotivo(String motivo) {
        this.motivo = motivo; }

    // Estado
    public String getEstado() {
        return estado; }
    public void setEstado(String estado) {
        this.estado = estado; }

    // Admin aprobador
    public Integer getIdAdminAprobador() {
        return idAdminAprobador; }
    public void setIdAdminAprobador(Integer idAdminAprobador) {
        this.idAdminAprobador = idAdminAprobador; }

    // Fecha aprobacion
    public LocalDate getFechaAprobacion() {
        return fechaAprobacion; }
    public void setFechaAprobacion(LocalDate fechaAprobacion) {
        this.fechaAprobacion = fechaAprobacion; }

    // Comentario de odio del admin al funcionario
    public String getComentarioAdmin() {
        return comentarioAdmin; }
    public void setComentarioAdmin(String comentarioAdmin) {
        this.comentarioAdmin = comentarioAdmin; }


    // Asi te justa organizado waflex?
}