package app.controllers;

import app.views.RegisterView;
import app.dao.FuncionarioDAO;
import app.models.Funcionario;
import app.views.RegisterView;

import javax.swing.*;

/**
 * Controlador para registrar nuevos funcionarios (desde el panel del administrador).
 */

public class RegisterController {
    private final RegisterView view;
    private final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

    public RegisterController(RegisterView view) {
        this.view = view;

        // Eventos de los botones Registrar y Volver
        this.view.btnRegistrar.addActionListener(e -> registrarFuncionario());
        this.view.btnVolver.addActionListener(e -> view.dispose());
    }


    // Y eso, no quiero agregar mas parametros ni tanto


    private void registrarFuncionario() {
        String nombre = view.txtNombre.getText().trim();
        String apellido = view.txtApellido.getText().trim();
        String correo = view.txtCorreo.getText().trim();
        String telefono = view.txtTelefono.getText().trim();
        String departamento = (String) view.cbDepartamento.getSelectedItem();
        boolean esAdmin = view.chkEsAdmin.isSelected();

        char[] pass1 = view.txtPassword.getPassword();
        char[] pass2 = view.txtConfirmPassword.getPassword();
        
        /** 
         * Validaciones para el formulario
         * */
        
        // Para completar los campos
        if (nombre.isEmpty() || apellido.isEmpty() || correo.isEmpty() || telefono.isEmpty() || pass1.length == 0) {
            view.lblStatus.setText("Completa todos los campos obligatorios.");
            return;
        }

        // Que las passwords sean las mismas
        if (!String.valueOf(pass1).equals(String.valueOf(pass2))) {
            view.lblStatus.setText("Las contrasenas no coinciden.");
            return;
        }

        // Longitud minima de password 0.2.0
        if (pass1.length < 8) {
            view.lblStatus.setText("La password debe tener al menos 8 caracteres.");
            return;
        }
        
        // Maximo de 9 digitos (numero chileno) 0.1.9
        if (!telefono.matches("\\d{9}")) {
            view.lblStatus.setText("El telefono debe tener exactamente 9 digitos.");
            return;
        }

        // Validacion adicional (puede ser opcional): formato basico del correo 0.2.0
        if (!correo.matches("^[\\w.%+-]+@[\\w.-]+\\.[A-Za-z]{2,}$")) {
            view.lblStatus.setText("Formato de correo invalido.");
            return;
        }

        // Validacion de correo en base de datos 0.2.0
        if (funcionarioDAO.existePorCorreo(correo)) {
            view.lblStatus.setText("El correo ya esta registrado.");
            return;
        }

        // Construccion del objeto modelo
        Funcionario f = new Funcionario();
        f.setNombre(nombre);
        f.setApellido(apellido);
        f.setCorreo(correo);
        f.setTelefono(telefono);
        f.setDepartamento(departamento);
        f.setEsAdmin(esAdmin);
        f.setPasswordHash(String.valueOf(pass1)); // Recuerden que insert() hara el hash

        // souf de prueba de debug
        System.out.println("registrado con exito");
        
        // Insercion de base de datos
        boolean exito = funcionarioDAO.insert(f);

        if (exito) {
            JOptionPane.showMessageDialog(view, "Funcionario registrado correctamente.");
            view.dispose();
        } else {

            // Puede fallar por condicion de carrera (otro registro inserto el mismo correo entre check y el insert)
            // 0.2.0
            if (funcionarioDAO.existePorCorreo(correo)) {
                view.lblStatus.setText("Ya existe otro correo electronico registrado.");
            } else {
                view.lblStatus.setText("Error al registrar funcionario, hubo un problema inesperado.");
            }
        }
    }
}