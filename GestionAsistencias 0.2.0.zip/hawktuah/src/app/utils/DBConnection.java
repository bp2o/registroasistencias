package app.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * DBConnection: administra una unica conexion JDBC a la base de datos MySQL.
 * Edita la URL, usuario y password segun tu entorno.
 */

public class DBConnection {
    private static Connection conn; // Ya no recuerdo por que existe eso

    // === EDITAR ESTOS DATOS SEGUN EL SERVIDOR ======= //

    private static final String URL = "jdbc:mysql://localhost:33065/empresa_asistencia2"; // Editar tu url
    private static final String USER = "root"; // Editar tu user
    private static final String PASS = ""; // Editar tu password

    // ================================================= //

    private static Connection connection;
    
    // Estado del último intento de conexión (útil para la UI)
    private static boolean lastConnectSuccessful = false;
    private static String lastConnectionMessage = "";

    /**
     * Inicializa la conexion
     */

    public static Connection getConnection() throws SQLException {
    	
        // Si no existe o esta cerrada, crear una nueva conexion
        if (connection == null || connection.isClosed()) {
            // Intentar cargar explícitamente el driver (ayuda a diagnosticar classpath)
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                System.out.println("Driver JDBC cargado correctamente.");
            } catch (ClassNotFoundException ex) {
                String msg = "Driver JDBC no encontrado en el classpath: " + ex.getMessage();
                System.err.println(msg);
                lastConnectSuccessful = false;
                lastConnectionMessage = msg;
                
                // No devolvemos aún: DriverManager puede detectar driver automáticamente
            }

            try {
                connection = DriverManager.getConnection(URL, USER, PASS);
                lastConnectSuccessful = true;
                lastConnectionMessage = "Conectado";
                System.out.println(lastConnectionMessage);
            } catch (SQLException ex) {
                lastConnectSuccessful = false;
                lastConnectionMessage = "No conectado";
                System.err.println(lastConnectionMessage);
                throw ex;
            }
        }
        return connection;
    }

    /**
     * Indica si el último intento de conexión fue exitoso.
     */
    public static boolean wasLastConnectSuccessful() {
        return lastConnectSuccessful;
    }

    /**
     * Mensaje del último intento de conexión (útil para mostrar al usuario).
     */
    public static String getLastConnectionMessage() {
        return lastConnectionMessage;
    }

    /**
     * Comprueba si la conexión a la base de datos está abierta y disponible.
     * @return true si la conexión existe y no está cerrada, false en caso contrario
     */
    public static boolean isConnected() {
        try {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Devuelve un mensaje legible indicando el estado de la conexión.
     * @return mensaje en español con el estado de la conexión
     */
    public static String getConnectionStatusMessage() {
        return isConnected() ? "Conectado a la base de datos" : "No conectado a la base de datos";
    }

    /**
     * Muestra un diálogo con el estado de la conexión (útil para interfaces Swing).
     */
    public static void showConnectionStatusDialog() {
        JOptionPane.showMessageDialog(null, getConnectionStatusMessage());
    }
    
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}