package app.models;

import app.models.Funcionario;

import javax.swing.table.AbstractTableModel;
import java.util.List;

public class FuncionarioTableModel extends AbstractTableModel {

    private String[] columnas = {"ID", "Nombre", "Apellido", "Correo", "Departamento", "Activo"};
    private List<Funcionario> funcionarios;

    public FuncionarioTableModel(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }

    @Override
    public int getRowCount() {
        return funcionarios.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int row, int col) {
        Funcionario f = funcionarios.get(row);

        switch (col) {
            case 0: return f.getId();
            case 1: return f.getNombre();
            case 2: return f.getApellido();
            case 3: return f.getCorreo();
            case 4: return f.getDepartamento();
            case 5: return f.isActivo() ? "Activo" : "Inactivo";
        }
        return null;
    }

    @Override
    public String getColumnName(int index) {
        return columnas[index];
    }

    public void setFuncionarios(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
        fireTableDataChanged();
    }
}
