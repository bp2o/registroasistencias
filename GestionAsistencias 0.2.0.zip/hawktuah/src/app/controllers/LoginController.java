package app.controllers;

import app.dao.*;
import app.models.*;
import app.views.*;

import java.awt.Color;
import java.util.List;

import javax.swing.*;

/**
 * LoginController: controla la autenticacion de funcionarios.
 */

public class LoginController {
    private final LoginView view;
    private final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

    public LoginController(LoginView view) {
        this.view = view;

        // Evento de login
        this.view.btnLogin.addActionListener(e -> login());
        
        // Mostrar el estado segun el ultimo intento de conexion registrado en DBConnection
        boolean conectado = false;
        String msg = "No se encuentra conexion a la base de datos";
        try {
            conectado = app.utils.DBConnection.wasLastConnectSuccessful();
            msg = app.utils.DBConnection.getLastConnectionMessage();
            
            // si no hay mensaje, poner uno por defecto
            if (msg == null || msg.trim().isEmpty()) {
                msg = conectado ? "Conectado a la base de datos" : "No se encuentra conexión a la base de datos";
            }
        } catch (Exception e) {
            conectado = false;
            msg = "No se encuentra conexion a la base de datos";
        }

        if (conectado) {
            view.lblStatus.setText(msg);
            view.lblStatus.setForeground(new Color(0, 153, 0));
            view.lblStatus.setBackground(new Color(230, 255, 230));
        } else {
            view.lblStatus.setText(msg);
            view.lblStatus.setForeground(Color.RED);
            view.lblStatus.setBackground(new Color(255, 230, 230));
        }
        view.lblStatus.setFont(view.lblStatus.getFont().deriveFont(11f));
    }

    /**
     * Intenta autenticar al funcionario.
     *
     * Sin parametros.
     */

    private void login() {
        String correo = view.txtEmail.getText().trim();
        char[] password = view.txtPassword.getPassword();

        if (correo.isEmpty() || password.length == 0) {
            view.lblStatus.setText("Por favor, ingresa tus credenciales.");
            return;
        }

        // Este autentica si esta correcto o no tu correo y/o contrasenha
        Funcionario funcionario = funcionarioDAO.authenticate(correo, password);
        
        if (funcionario != null && !funcionario.isActivo()) {
        	view.lblStatus.setText("Tu cuenta esta INACTIVA");
        	return;
        }
        
        if (funcionario != null) {
            view.dispose();

            if (funcionario.isEsAdmin()) {
                abrirDashboardAdmin(funcionario);
            } else {
                abrirDashboardFuncionario(funcionario);
            }
        } else {
            view.lblStatus.setText("Credenciales incorrectas o usuario inactivo.");
        }
    }

    /**
     * Abre el dashboard del administrador.
     *
     * Sin parametros.
     */

    private void abrirDashboardAdmin(Funcionario admin) {
        AdminDashboardView adminDashboard = new AdminDashboardView(admin.getNombre() + " " + admin.getApellido());

        adminDashboard.btnCerrarSesion.addActionListener(e -> logout(adminDashboard));
        adminDashboard.btnHorarios.addActionListener(e -> openAdminHorarios(adminDashboard, admin));
        adminDashboard.btnJustificaciones.addActionListener(e -> openAdminJustificaciones(adminDashboard, admin));
        adminDashboard.btnGestionarFuncionario.addActionListener(e -> openGestionarFuncionarioView(adminDashboard));
        adminDashboard.btnRegistrarFuncionario.addActionListener(e -> openRegisterView(adminDashboard));
        
        adminDashboard.setVisible(true);
    }

    /**
     * Abre el dashboard del funcionario normal.
     *
     * ... Sin parametros
     */

    private void abrirDashboardFuncionario(Funcionario func) {
        FuncionarioDashboardView funcDashboard = new FuncionarioDashboardView(func.getNombre() + " " + func.getApellido());
        funcDashboard.btnCerrarSesion.addActionListener(e -> logout(funcDashboard));
        funcDashboard.btnVerHorarios.addActionListener(e -> openFuncionarioHorarios(funcDashboard, func));
        funcDashboard.btnCrearJustificacion.addActionListener(e -> openCrearJustificacion(funcDashboard, func));
        funcDashboard.setVisible(true);
    }

    /**
     * Al cerrar sesion, te devuelves al panel de iniciar sesion algo asi
     *
     * ... No se en donde agregarle parametros
     * */

    private void logout(JFrame dash) {
        dash.dispose();
        LoginView lv = new LoginView();
        new LoginController(lv);
        lv.setVisible(true);
    }

    // Cambios realizados desde la 0.1.2

    /**
     * Abre el panel de administración de horarios para un administrador.
     * Permite: listar, crear, editar y eliminar horarios asignados a funcionarios.
     *
     * @param parent Ventana desde la cual fue llamado (se oculta temporalmente)
     * @param admin Objeto Funcionario del administrador logueado
     */

    private void openAdminHorarios(JFrame parent, Funcionario admin) {
        AdminHorariosView view = new AdminHorariosView();
        app.dao.HorarioDAO dao = new app.dao.HorarioDAO();

        // Carga inicial de la tabla
        view.loadData(dao.findAllWithFuncionario());

        // Boton de agregar
        view.btnAgregar.addActionListener(e -> {
        	
            // false = modo agregar, null = sin datos iniciales
            HorarioFormView form = new HorarioFormView(view, false, null);

            form.btnGuardar.addActionListener(ev -> {
                try {
                    HorarioProgramado nuevo = form.getHorario();
                    
                    if (dao.insert(nuevo)) {
                        view.loadData(dao.findAllWithFuncionario());
                        form.dispose();
                    } else {
                        JOptionPane.showMessageDialog(form, "Error al insertar horario.");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(form, "Error: " + ex.getMessage());
                }
            });

            form.btnCancelar.addActionListener(ev -> form.dispose());

            // 0.1.9
            form.setVisible(true); // Se soluciono para que no se abra el panel admin
        });

        // Boton de editar
        view.btnEditar.addActionListener(e -> {
            int id = view.getSelectedId();
            if (id == -1) {
                JOptionPane.showMessageDialog(view, "Selecciona un horario primero.");
                return;
            }

            HorarioProgramado horario = dao.getById(id);
            if (horario == null) {
                JOptionPane.showMessageDialog(view, "No se encontro el horario.");
                return;
            }

            HorarioFormView form = new HorarioFormView(view, true, horario);

            form.btnGuardar.addActionListener(ev -> {
                try {
                    HorarioProgramado edited = form.getHorario();
                    if (dao.update(edited)) {
                        view.loadData(dao.findAllWithFuncionario());
                        form.dispose();
                    } else {
                        JOptionPane.showMessageDialog(form, "Error al actualizar horario.");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(form, "Error: " + ex.getMessage());
                }
            });

            form.btnCancelar.addActionListener(ev -> form.dispose());

            // 0.1.9
            form.setVisible(true); // Tambien eso
        });

        // Boton de eliminar
        view.btnEliminar.addActionListener(e -> {
            int id = view.getSelectedId();
            if (id == -1) {
                JOptionPane.showMessageDialog(view, "Selecciona un horario primero.");
                return;
            }

            if (JOptionPane.showConfirmDialog(view, "�Eliminar el horario seleccionado?", "Confirmar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                if (dao.delete(id)) {
                    view.loadData(dao.findAllWithFuncionario());
                } else {
                    JOptionPane.showMessageDialog(view, "Error al eliminar.");
                }
            }
        });

        // Boton de volver
        view.btnVolver.addActionListener(e -> {
            view.dispose();
            parent.setVisible(true);
        });

        parent.setVisible(false);
        view.setVisible(true);
    }

    /**
     * Vista para que el administrador revise, apruebe y rechace justificones.
     *
     * @param parent Ventana anterior
     * @param admin Administrador actual
     */

    private void openAdminJustificaciones(JFrame parent, Funcionario admin) {
        AdminJustificacionesView view = new AdminJustificacionesView();
        app.dao.JustificacionDAO dao = new app.dao.JustificacionDAO();

        // Cargar datos
        view.loadData(dao.findAllWithFuncionario());

        // Boton de aprobar
        view.btnAprobar.addActionListener(e -> {
            int id = view.getSelectedId();
            if (id == -1) { JOptionPane.showMessageDialog(view, "Selecciona una justificacion."); return; }

            String comentario = JOptionPane.showInputDialog(view, "Comentario (opcional) al aprobar:");
            boolean ok = dao.updateEstado(id, "Aprobado", admin.getId(), new java.sql.Timestamp(System.currentTimeMillis()), comentario);

            if (ok) view.loadData(dao.findAllWithFuncionario());
            else JOptionPane.showMessageDialog(view, "Error al aprobar.");
        });

        // Boton de rechazar
        view.btnRechazar.addActionListener(e -> {
            int id = view.getSelectedId();
            if (id == -1) { JOptionPane.showMessageDialog(view, "Selecciona una justificacion."); return; }

            String motivo = JOptionPane.showInputDialog(view, "Motivo de rechazo (opcional):");
            boolean ok = dao.updateEstado(id, "Rechazado", admin.getId(), new java.sql.Timestamp(System.currentTimeMillis()), motivo);

            if (ok) view.loadData(dao.findAllWithFuncionario());
            else JOptionPane.showMessageDialog(view, "Error al rechazar.");
        });

        view.btnVolver.addActionListener(e -> {
            view.dispose();
            parent.setVisible(true);
        });

        parent.setVisible(false);
        view.setVisible(true);
    }

    /**
     * Vista de consulta de horarios para un funcionario normal.
     * Solo permite visualizar, no editar.
     */

    private void openFuncionarioHorarios(JFrame parent, Funcionario func) {
        FuncionarioHorariosView view = new FuncionarioHorariosView();
        app.dao.HorarioDAO dao = new app.dao.HorarioDAO();

        view.loadData(dao.findByFuncionario(func.getId()));

        view.btnVolver.addActionListener(e -> {
            view.dispose();
            parent.setVisible(true);
        });

        parent.setVisible(false);
        view.setVisible(true);
    }

    /**
     * Pantalla para que un funcionario enviee una solicitud de justificacion
     * (permiso de ausencia).
     */

    private void openCrearJustificacion(JFrame parent, Funcionario func) {
        FuncionarioCrearJustificacionView view = new FuncionarioCrearJustificacionView();
        app.dao.JustificacionDAO dao = new app.dao.JustificacionDAO();

        
        view.btnCrear.addActionListener(e -> {
            try {
                java.sql.Date inicio = new java.sql.Date(((java.util.Date)view.spFechaInicio.getValue()).getTime());
                java.sql.Date fin = new java.sql.Date(((java.util.Date)view.spFechaFin.getValue()).getTime());
                String motivo = view.taMotivo.getText().trim();

                if (motivo.isEmpty()) {
                    JOptionPane.showMessageDialog(view, "Escribe un motivo.");
                    return;
                }

                if (dao.create(func.getId(), inicio, fin, motivo)) {
                    JOptionPane.showMessageDialog(view, "Justificacion enviada.");
                    view.dispose();
                    parent.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(view, "Error al enviar justificacion.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(view, "Error: " + ex.getMessage());
            }
        });
        
        view.btnVerJustificacion.addActionListener(e -> openVerJustificacion(view, func));

        view.btnVolver.addActionListener(e -> {
            view.dispose();
            parent.setVisible(true);
        });

        parent.setVisible(false);
        view.setVisible(true);
    }
    
    // Nuevo metodo para que el funcionario vea sus justificaciones actualizadas   0.1.6
    public void openVerJustificacion(JFrame parent, Funcionario func) {
    	FuncionarioVerJustificacionView view = new FuncionarioVerJustificacionView();
    	JustificacionDAO dao = new JustificacionDAO();
    	
    	//Cargar datos
    	List<Justificacion> list = dao.findByFuncionario(func.getId());
    	Object[][] data = new Object[list.size()][5];
    	
    	for (int i = 0; i < list.size(); i++) {
    		Justificacion j = list.get(i);
    		data[i][0] = j.getFechaInicio();
    		data[i][1] = j.getFechaFin();
    		data[i][2] = j.getMotivo();
    		data[i][3] = j.getEstado();
    		data[i][4] = j.getComentarioAdmin();
    	}
    	
    	// Para que cargue los datos en la vista
    	view.loadData(data);
    	
    	// Boton para volver lol
    	view.btnVolver.addActionListener(e -> {
    		view.dispose();
    		parent.setVisible(true);
    	});
    	
    	parent.setVisible(false);
    	view.setVisible(true);
    }
    
    // Para que escuche el boton Register en el panel del Admin 0.1.4
    public void openRegisterView(JFrame parent) {
        RegisterView registerView = new RegisterView();
        new RegisterController(registerView); // Supongo que eso conecta al cotrolador
        
        parent.setVisible(false);
        
        registerView.btnVolver.addActionListener(e -> {
        	registerView.dispose();
        	parent.setVisible(true);
        });
        
        registerView.setVisible(true);
    }
    
    // Nuevo metodo para que se abra el panel de GestionarFuncionarioView 0.2.0
    // Que tenga que ver con FuncionarioTableModel, Funcionario, FuncionarioDAO, etc..
    public void openGestionarFuncionarioView(JFrame parent) {
        GestionarFuncionarioView gfw = new GestionarFuncionarioView();

        // Acci�n del bot�n VOLVER
        gfw.btnVolver.addActionListener(e -> {
            gfw.dispose();
            parent.setVisible(true);
        });

        parent.setVisible(false);
        gfw.setVisible(true);
    }
}