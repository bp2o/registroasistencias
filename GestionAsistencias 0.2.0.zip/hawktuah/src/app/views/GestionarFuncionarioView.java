package app.views;

import app.dao.FuncionarioDAO;
import app.models.FuncionarioTableModel;

import javax.swing.*;
import java.awt.*;

public class GestionarFuncionarioView extends JFrame {

    private final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    private JTable tabla;
    private FuncionarioTableModel tableModel;

    // Bot�n que el controlador usar� para volver
    public JButton btnVolver;

    // Botones internos
    private JButton btnActivar;
    private JButton btnInactivar;

    public GestionarFuncionarioView() {
        setTitle("Gesti�n de Funcionarios");
        setSize(900, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel Superior
        JLabel lblTitulo = new JLabel("Gesti�n de Funcionarios", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(lblTitulo, BorderLayout.NORTH);

        // Tabla de funcionarios
        tableModel = new FuncionarioTableModel(funcionarioDAO.obtenerTodos());
        tabla = new JTable(tableModel);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(scroll, BorderLayout.CENTER);

        // Panel de botones
        btnActivar = new JButton("Marcar como ACTIVO");
        btnInactivar = new JButton("Marcar como INACTIVO");
        btnVolver = new JButton("Volver");

        btnActivar.setPreferredSize(new Dimension(180, 35));
        btnInactivar.setPreferredSize(new Dimension(180, 35));
        btnVolver.setPreferredSize(new Dimension(120, 35));

        JPanel panelBotones = new JPanel();
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBotones.add(btnActivar);
        panelBotones.add(btnInactivar);
        panelBotones.add(btnVolver);

        add(panelBotones, BorderLayout.SOUTH);

        // Eventos de los botones
        btnActivar.addActionListener(e -> cambiarEstado(true));
        btnInactivar.addActionListener(e -> cambiarEstado(false));
    }

    // Cambia el estado activo/inactivo del funcionario seleccionado en la tabla.
    private void cambiarEstado(boolean activar) {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Debes seleccionar un funcionario.", 
                    "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) tabla.getValueAt(fila, 0);

        boolean exito = funcionarioDAO.cambiarEstado(id, activar);

        if (exito) {
            JOptionPane.showMessageDialog(this,
                    activar ? "Funcionario ACTIVADO correctamente." :
                              "Funcionario INACTIVADO correctamente.");

            // Actualiza la tabla
            tableModel.setFuncionarios(funcionarioDAO.obtenerTodos());
        } else {
            JOptionPane.showMessageDialog(this,
                    "Error al actualizar el estado del funcionario.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
