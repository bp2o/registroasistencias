package app.views;

import javax.swing.*;
import java.awt.*;

/**
 * LoginView: formulario simple de inicio de sesion.
 */

public class LoginView extends JFrame {

	// Mas atributos...
    public JTextField txtEmail = new JTextField(25);
    public JPasswordField txtPassword = new JPasswordField(25);
    public JButton btnLogin = new JButton("Iniciar sesion");
    public JLabel lblStatus = new JLabel("Conectado a la base de datos");

    public LoginView() {
    	
    	// cfg
    	setResizable(false);
        setTitle("Sistema de Asistencia 0.2.0 - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 250);
        setLocationRelativeTo(null);

        // palel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // add eso
        panel.add(new JLabel("Correo:"));
        panel.add(txtEmail);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(new JLabel("Contrasena:"));
        panel.add(txtPassword);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        // el boton de login
        JPanel panelLogin = new JPanel();
        panelLogin.add(btnLogin);
        panel.add(panelLogin);

        // 0.1.8 Cambio realizado por el Nico
        
        // donde se posiciona supongo
        // mejorar visibilidad de la etiqueta de estado (por defecto: conectado, verde y pequeño)
        lblStatus.setOpaque(true);
        lblStatus.setBorder(BorderFactory.createEmptyBorder(4, 6, 4, 6));
        lblStatus.setHorizontalAlignment(SwingConstants.RIGHT);
        lblStatus.setForeground(new Color(0, 153, 0));
        lblStatus.setFont(lblStatus.getFont().deriveFont(11f));
        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(lblStatus, BorderLayout.SOUTH);
    }
}