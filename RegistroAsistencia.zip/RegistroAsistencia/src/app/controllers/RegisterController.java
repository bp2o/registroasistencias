package app.controllers;

import app.dao.FuncionarioDAO;
import app.utils.PasswordUtils;
import app.views.RegisterView;
import app.views.LoginView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * RegisterController: maneja el proceso de registro de nuevos funcionarios.
 */
public class RegisterController {
    private final RegisterView view;
    private final FuncionarioDAO funcionarioDAO;

    public RegisterController(RegisterView view) {
        this.view = view;
        this.funcionarioDAO = new FuncionarioDAO();
        initController();
    }

    private void initController() {
        view.btnRegistrar.addActionListener(e -> registrarFuncionario());
        view.btnVolver.addActionListener(e -> volverALogin());
    }

    private void registrarFuncionario() {
        // Obtener datos del formulario
        String nombre = view.txtNombre.getText().trim();
        String apellido = view.txtApellido.getText().trim();
        String correo = view.txtCorreo.getText().trim();
        char[] password = view.txtPassword.getPassword();
        char[] confirmPassword = view.txtConfirmPassword.getPassword();
        String telefono = view.txtTelefono.getText().trim();
        String departamento = (String) view.cbDepartamento.getSelectedItem();

        // Validaciones
        if (nombre.isEmpty() || apellido.isEmpty() || correo.isEmpty() ||
                password.length == 0 || telefono.isEmpty()) {
            view.lblStatus.setText("Todos los campos son obligatorios");
            return;
        }

        if (!validarCorreo(correo)) {
            view.lblStatus.setText("Formato de correo inválido");
            return;
        }

        if (password.length < 6) {
            view.lblStatus.setText("La contraseña debe tener al menos 6 caracteres");
            return;
        }

        if (!validarContrasenasIguales(password, confirmPassword)) {
            view.lblStatus.setText("Las contraseñas no coinciden");
            return;
        }

        if (!validarTelefono(telefono)) {
            view.lblStatus.setText("Formato de teléfono inválido");
            return;
        }

        try {
            // Hash de la contraseña
            String passwordHash = PasswordUtils.hashPassword(password);

            // Registrar en la base de datos
            boolean exito = funcionarioDAO.registrarFuncionario(
                    nombre, apellido, correo, passwordHash, telefono, departamento);

            if (exito) {
                JOptionPane.showMessageDialog(view,
                        "Registro exitoso. Ahora puede iniciar sesión.",
                        "Registro Completado",
                        JOptionPane.INFORMATION_MESSAGE);
                volverALogin();
            } else {
                view.lblStatus.setText("Error al registrar. El correo puede estar en uso.");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            view.lblStatus.setText("Error interno del sistema");
        }
    }

    private boolean validarCorreo(String correo) {
        return correo.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    private boolean validarContrasenasIguales(char[] pass1, char[] pass2) {
        if (pass1.length != pass2.length) return false;
        for (int i = 0; i < pass1.length; i++) {
            if (pass1[i] != pass2[i]) return false;
        }
        return true;
    }

    private boolean validarTelefono(String telefono) {
        return telefono.matches("^[0-9+\\-\\s()]{8,15}$");
    }

    private void volverALogin() {
        view.dispose();
        LoginView loginView = new LoginView();
        new LoginController(loginView);
        loginView.setVisible(true);
    }
}