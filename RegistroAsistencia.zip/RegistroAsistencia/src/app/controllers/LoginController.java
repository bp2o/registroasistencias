package app.controllers;

import app.dao.AdminDAO;
import app.dao.FuncionarioDAO;
import app.dao.HorarioDAO;
import app.dao.JustificacionDAO;
import app.models.Administrador;
import app.models.Funcionario;
import app.models.HorarioProgramado;
import app.views.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.List;

/**
 * LoginController: controla el flujo de inicio de sesión y abre los dashboards correspondientes.
 */

public class LoginController {
    private final LoginView view;
    private final AdminDAO adminDAO = new AdminDAO();
    private final FuncionarioDAO funcDAO = new FuncionarioDAO();


    public LoginController(LoginView view) {
        this.view = view;
        initController();
    }


    private void initController() {
        view.btnLogin.addActionListener(e -> login());
        view.btnRegistrar.addActionListener(e -> abrirRegistro());
    }


    private void login() {
        String correo = view.txtEmail.getText().trim();
        char[] pass = view.txtPassword.getPassword();


        Administrador admin = adminDAO.authenticate(correo, pass);
        if (admin != null) {
            view.dispose();
            AdminDashboardView dash = new AdminDashboardView(admin.getNombreCompleto());
        // listeners
            dash.btnCerrarSesion.addActionListener(e -> logout(dash));
            dash.btnHorarios.addActionListener(e -> openAdminHorarios(dash, admin));
            dash.btnJustificaciones.addActionListener(e -> openAdminJustificaciones(dash, admin));
            dash.setVisible(true);
            return;
        }


        Funcionario func = funcDAO.authenticate(correo, pass);
        if (func != null) {
            view.dispose();
            FuncionarioDashboardView fdash = new FuncionarioDashboardView(func.getNombreCompleto());
            fdash.btnCerrarSesion.addActionListener(e -> logout(fdash));
            fdash.btnVerHorarios.addActionListener(e -> openFuncionarioHorarios(fdash, func));
            fdash.btnCrearJustificacion.addActionListener(e -> openCrearJustificacion(fdash, func));
            fdash.setVisible(true);
            return;
        }


        view.lblStatus.setText("Credenciales incorrectas.");
    }

    private void abrirRegistro() {
        view.dispose();
        RegisterView registerView = new RegisterView();
        new RegisterController(registerView);
        registerView.setVisible(true);
    }

    private void logout(JFrame dash) {
        dash.dispose();
        LoginView lv = new LoginView();
        new LoginController(lv);
        lv.setVisible(true);
    }


    // ---------- ADMIN: HORARIOS ----------
    private void openAdminHorarios(JFrame parent, Administrador admin) {
        AdminHorariosView v = new AdminHorariosView();
        HorarioDAO dao = new HorarioDAO();
        List<HorarioProgramado> list = dao.findAllWithFuncionario();
        v.loadData(list);


        v.btnVolver.addActionListener(e -> { v.dispose(); parent.setVisible(true); });


        // Acciones CRUD (simplificadas: abrir formularios Java Swing para agregar/editar no incluidos aquí por brevedad)
        v.btnEliminar.addActionListener(e -> {
            int id = v.getSelectedId();
            if (id == -1) { JOptionPane.showMessageDialog(v, "Seleccione un horario para eliminar."); return; }
            int ok = JOptionPane.showConfirmDialog(v, "¿Eliminar horario seleccionado?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (ok == JOptionPane.YES_OPTION) {
                boolean removed = dao.delete(id);
                if (removed) { JOptionPane.showMessageDialog(v, "Horario eliminado."); v.loadData(dao.findAllWithFuncionario()); }
                else JOptionPane.showMessageDialog(v, "Error eliminando horario.");
            }
        });


        v.setVisible(true);
        parent.setVisible(false);
    }

    // ---------- ADMIN: JUSTIFICACIONES ----------
    private void openAdminJustificaciones(JFrame parent, Administrador admin) {
        AdminJustificacionesView v = new AdminJustificacionesView();
        JustificacionDAO dao = new JustificacionDAO();
        v.loadData(dao.findAllWithFuncionario());


        v.btnVolver.addActionListener(e -> { v.dispose(); parent.setVisible(true); });


        // Aprobar / Rechazar (simplificado: solo muestra mensaje y debería implementar update en DAO)
        v.btnAprobar.addActionListener(e -> {
            int id = v.getSelectedId(); if (id == -1) { JOptionPane.showMessageDialog(v, "Seleccione una justificación."); return; }
            JOptionPane.showMessageDialog(v, "Funcionalidad aprobar (implementar update en DAO). ID: " + id);
        });
        v.btnRechazar.addActionListener(e -> {
            int id = v.getSelectedId(); if (id == -1) { JOptionPane.showMessageDialog(v, "Seleccione una justificación."); return; }
            JOptionPane.showMessageDialog(v, "Funcionalidad rechazar (implementar update en DAO). ID: " + id);
        });


        v.setVisible(true);
        parent.setVisible(false);
    }

    // ---------- FUNCIONARIO: VER HORARIOS ---------- //

    private void openFuncionarioHorarios(JFrame parent, Funcionario func) {
        FuncionarioHorariosView v = new FuncionarioHorariosView();
        HorarioDAO dao = new HorarioDAO();
        v.loadData(dao.findByFuncionario(func.getId()));


        v.btnVolver.addActionListener(e -> { v.dispose(); parent.setVisible(true); });
        v.setVisible(true);
        parent.setVisible(false);
    }

    // ---------- FUNCIONARIO: CREAR JUSTIFICACION ---------- //

    private void openCrearJustificacion(JFrame parent, Funcionario func) {
        FuncionarioCrearJustificacionView v = new FuncionarioCrearJustificacionView();
        JustificacionDAO dao = new JustificacionDAO();


        v.btnVolver.addActionListener(e -> { v.dispose(); parent.setVisible(true); });
        v.btnCrear.addActionListener(e -> {
            java.util.Date d1 = (java.util.Date) v.spFechaInicio.getValue();
            java.util.Date d2 = (java.util.Date) v.spFechaFin.getValue();
            String motivo = v.taMotivo.getText().trim();
            if (motivo.isEmpty()) { JOptionPane.showMessageDialog(v, "Ingrese un motivo"); return; }
            boolean ok = dao.create(func.getId(), new Date(d1.getTime()), new Date(d2.getTime()), motivo);
            if (ok) { JOptionPane.showMessageDialog(v, "Justificación creada (pendiente)"); v.dispose(); parent.setVisible(true); }
            else JOptionPane.showMessageDialog(v, "Error creando justificación");
        });


        v.setVisible(true);
        parent.setVisible(false);
    }

    // me dio paja diseñar ts pmo sybau 67 mango mustard   -bp2o

    private void openAgregarHorario(AdminHorariosView parentView, HorarioDAO dao) {
        HorarioFormView form = new HorarioFormView(parentView, false, null);

        form.btnGuardar.addActionListener(e -> {
            HorarioProgramado nuevoHorario = form.getHorario();

            // Validaciones básicas
            if (nuevoHorario.getHoraEntrada().after(nuevoHorario.getHoraSalida())) {
                JOptionPane.showMessageDialog(form, "La hora de entrada no puede ser posterior a la hora de salida");
                return;
            }

            boolean success = dao.insert(nuevoHorario);
            if (success) {
                JOptionPane.showMessageDialog(form, "Horario agregado exitosamente");
                form.dispose();
                refreshHorarios(parentView, dao);
            } else {
                JOptionPane.showMessageDialog(form, "Error al agregar horario");
            }
        });

        form.btnCancelar.addActionListener(e -> form.dispose());

        form.setVisible(true);
    }

    private void openEditarHorario(AdminHorariosView parentView, HorarioDAO dao) {
        int selectedId = parentView.getSelectedId();
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(parentView, "Seleccione un horario para editar");
            return;
        }

        // Buscar el horario seleccionado
        HorarioProgramado horarioSeleccionado = null;
        List<HorarioProgramado> horarios = dao.findAllWithFuncionario();
        for (HorarioProgramado h : horarios) {
            if (h.getId() == selectedId) {
                horarioSeleccionado = h;
                break;
            }
        }

        if (horarioSeleccionado == null) {
            JOptionPane.showMessageDialog(parentView, "Horario no encontrado");
            return;
        }

        HorarioFormView form = new HorarioFormView(parentView, true, horarioSeleccionado);

        form.btnGuardar.addActionListener(e -> {
            HorarioProgramado horarioEditado = form.getHorario();

            // Validaciones básicas
            if (horarioEditado.getHoraEntrada().after(horarioEditado.getHoraSalida())) {
                JOptionPane.showMessageDialog(form, "La hora de entrada no puede ser posterior a la hora de salida");
                return;
            }

            boolean success = dao.update(horarioEditado);
            if (success) {
                JOptionPane.showMessageDialog(form, "Horario actualizado exitosamente");
                form.dispose();
                refreshHorarios(parentView, dao);
            } else {
                JOptionPane.showMessageDialog(form, "Error al actualizar horario");
            }
        });

        form.btnCancelar.addActionListener(e -> form.dispose());

        form.setVisible(true);
    }

    private void refreshHorarios(AdminHorariosView view, HorarioDAO dao) {
        List<HorarioProgramado> listaActualizada = dao.findAllWithFuncionario();
        view.loadData(listaActualizada);
    }
}