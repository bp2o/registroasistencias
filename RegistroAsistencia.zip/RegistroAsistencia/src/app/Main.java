package app;

import app.controllers.LoginController;
import app.views.LoginView;
import app.utils.DBConnection;
import app.utils.UITheme;

/**
 * Punto de entrada de la aplicación.
 * Inicializa el tema UI, la conexión a la base de datos y abre la vista de login.
 */
public class Main {
    public static void main(String[] args) {

        // Aplicar tema visual (colores configurables en UITheme)
        UITheme.applyTheme();

        // Inicializar la conexión a la base de datos (revisar app.utils.DBConnection)
        DBConnection.init();

        // Lanzar la interfaz en el hilo de Swing
        javax.swing.SwingUtilities.invokeLater(() -> {
            LoginView view = new LoginView();
            new LoginController(view);
            view.setVisible(true);
        });
    }
}