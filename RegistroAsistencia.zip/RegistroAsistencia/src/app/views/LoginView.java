package app.views;

import javax.swing.*;
import java.awt.*;

/**
 * LoginView: formulario simple de inicio de sesión con opción de registro.
 */

public class LoginView extends JFrame {
    public JTextField txtEmail = new JTextField(25);
    public JPasswordField txtPassword = new JPasswordField(25);
    public JButton btnLogin = new JButton("Iniciar sesión");
    public JButton btnRegistrar = new JButton("Registrar nuevo funcionario");
    public JLabel lblStatus = new JLabel(" ");

    public LoginView() {
        setTitle("Sistema de Asistencia - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(420, 300); // Aumentado un poco la altura
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Correo:"));
        panel.add(txtEmail);
        panel.add(Box.createRigidArea(new Dimension(0,10)));
        panel.add(new JLabel("Contraseña:"));
        panel.add(txtPassword);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        // Panel para botones de login
        JPanel panelLogin = new JPanel();
        panelLogin.add(btnLogin);
        panel.add(panelLogin);

        panel.add(Box.createRigidArea(new Dimension(0,10)));

        // Separador
        JSeparator separator = new JSeparator();
        separator.setMaximumSize(new Dimension(350, 1));
        panel.add(separator);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        // Texto para registro
        JLabel lblRegistro = new JLabel("¿No tienes cuenta?");
        lblRegistro.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(lblRegistro);
        panel.add(Box.createRigidArea(new Dimension(0,5)));

        // Botón de registro
        JPanel panelRegistro = new JPanel();
        panelRegistro.add(btnRegistrar);
        panel.add(panelRegistro);

        add(panel, BorderLayout.CENTER);
        add(lblStatus, BorderLayout.SOUTH);
    }
}