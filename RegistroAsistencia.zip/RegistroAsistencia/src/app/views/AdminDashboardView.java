package app.views;

import javax.swing.*;
import java.awt.*;

/**
 * AdminDashboardView: panel principal para administradores con botones a funcionalidades.
 */

public class AdminDashboardView extends JFrame {
    public JButton btnHorarios = new JButton("Gestionar Horarios");
    public JButton btnJustificaciones = new JButton("Ver Justificaciones");
    public JButton btnCerrarSesion = new JButton("Cerrar sesión");
    public JLabel lblUsuario = new JLabel();


    public AdminDashboardView(String nombreUsuario) {
        setTitle("Dashboard - Administrador");
        setSize(600, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);


        lblUsuario.setText("Conectado: " + nombreUsuario);


        JPanel panel = new JPanel(new GridLayout(4,1,10,10));
        panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        panel.add(lblUsuario);
        panel.add(btnHorarios);
        panel.add(btnJustificaciones);
        panel.add(btnCerrarSesion);
        add(panel);
    }
}