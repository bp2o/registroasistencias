package app.views;

import javax.swing.*;
import java.awt.*;

/**
 * RegisterView: formulario de registro para nuevos funcionarios.
 */

public class RegisterView extends JFrame {
    public JTextField txtNombre = new JTextField(25);
    public JTextField txtApellido = new JTextField(25);
    public JTextField txtCorreo = new JTextField(25);
    public JPasswordField txtPassword = new JPasswordField(25);
    public JPasswordField txtConfirmPassword = new JPasswordField(25);
    public JTextField txtTelefono = new JTextField(25);
    public JComboBox<String> cbDepartamento = new JComboBox<>();
    public JButton btnRegistrar = new JButton("Registrar");
    public JButton btnVolver = new JButton("Volver al Login");
    public JLabel lblStatus = new JLabel(" ");

    public RegisterView() {
        setTitle("Registro de Funcionario");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(450, 500);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Campos del formulario
        panel.add(new JLabel("Nombre:"));
        panel.add(txtNombre);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        panel.add(new JLabel("Apellido:"));
        panel.add(txtApellido);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        panel.add(new JLabel("Correo electrónico:"));
        panel.add(txtCorreo);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        panel.add(new JLabel("Contraseña:"));
        panel.add(txtPassword);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        panel.add(new JLabel("Confirmar Contraseña:"));
        panel.add(txtConfirmPassword);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        panel.add(new JLabel("Teléfono:"));
        panel.add(txtTelefono);
        panel.add(Box.createRigidArea(new Dimension(0,10)));

        panel.add(new JLabel("Departamento:"));

        // Departamentos según tu ENUM en la BD
        String[] departamentos = {"RRHH", "Contabilidad", "TI", "Logistica"};
        for (String depto : departamentos) {
            cbDepartamento.addItem(depto);
        }
        panel.add(cbDepartamento);
        panel.add(Box.createRigidArea(new Dimension(0,15)));

        // Botones
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnRegistrar);
        panelBotones.add(btnVolver);
        panel.add(panelBotones);

        // Status label
        panel.add(Box.createRigidArea(new Dimension(0,10)));
        panel.add(lblStatus);

        add(panel);
    }
}