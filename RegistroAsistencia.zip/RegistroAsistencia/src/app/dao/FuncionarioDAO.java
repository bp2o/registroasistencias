package app.dao;

import app.models.Funcionario;
import app.utils.DBConnection;
import app.utils.PasswordUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * FuncionarioDAO: operaciones para autenticar y obtener datos de funcionarios.
 */

public class FuncionarioDAO {
    public Funcionario authenticate(String correo, char[] password) {
        String sql = "SELECT id_funcionario, nombre, apellido, correo, password_hash, departamento FROM Funcionario WHERE correo = ? AND activo = TRUE";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, correo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String stored = rs.getString("password_hash");
                if (PasswordUtils.verifyPassword(password, stored)) {
                    Funcionario f = new Funcionario();
                    f.setId(rs.getInt("id_funcionario"));
                    f.setNombre(rs.getString("nombre"));
                    f.setApellido(rs.getString("apellido"));
                    f.setCorreo(rs.getString("correo"));
                    f.setPasswordHash(stored);
                    f.setDepartamento(rs.getString("departamento"));
                    return f;
                }
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        return null;
    }

    /**
     * Obtiene todos los funcionarios activos para mostrar en combobox
     */

    public Map<String, Integer> getFuncionariosActivos() {
        Map<String, Integer> funcionarios = new LinkedHashMap<>();
        String sql = "SELECT id_funcionario, nombre, apellido, departamento FROM Funcionario WHERE activo = TRUE ORDER BY nombre, apellido";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String nombreCompleto = rs.getString("nombre") + " " +
                        rs.getString("apellido") + " - " +
                        rs.getString("departamento");
                funcionarios.put(nombreCompleto, rs.getInt("id_funcionario"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return funcionarios;
    }

    public boolean registrarFuncionario(String nombre, String apellido, String correo,
                                        String passwordHash, String telefono, String departamento) {
        String sql = "INSERT INTO Funcionario (nombre, apellido, correo, password_hash, telefono, departamento, fecha_contratacion) " +
                "VALUES (?, ?, ?, ?, ?, ?, CURDATE())";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setString(3, correo);
            ps.setString(4, passwordHash);
            ps.setString(5, telefono);
            ps.setString(6, departamento);

            return ps.executeUpdate() == 1;

        } catch (SQLException ex) {
            // Si es violación de UNIQUE constraint (correo duplicado)
            if (ex.getErrorCode() == 1062) {
                return false;
            }
            ex.printStackTrace();
            return false;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}