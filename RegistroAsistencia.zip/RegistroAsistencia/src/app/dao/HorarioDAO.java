package app.dao;

import app.models.HorarioProgramado;
import app.utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * HorarioDAO: CRUD para horarios programados.
 */

public class HorarioDAO {

    /**
     * Obtiene todos los horarios junto al nombre del funcionario (JOIN) para mostrar en la tabla.
     */

    public List<HorarioProgramado> findAllWithFuncionario() {
        List<HorarioProgramado> list = new ArrayList<>();
        String sql = "SELECT h.id_horario, h.id_funcionario, CONCAT(f.nombre,' ',f.apellido) AS nombre_funcionario, h.dia_semana, h.hora_entrada, h.hora_salida, h.es_excepcion, h.fecha_excepcion FROM HorarioProgramado h JOIN Funcionario f ON h.id_funcionario = f.id_funcionario ORDER BY f.nombre, h.dia_semana";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                HorarioProgramado h = new HorarioProgramado();
                h.setId(rs.getInt("id_horario"));
                h.setIdFuncionario(rs.getInt("id_funcionario"));
                h.setNombreFuncionario(rs.getString("nombre_funcionario"));
                h.setDiaSemana(rs.getString("dia_semana"));
                h.setHoraEntrada(rs.getTime("hora_entrada"));
                h.setHoraSalida(rs.getTime("hora_salida"));
                h.setEsExcepcion(rs.getBoolean("es_excepcion"));
                Date fe = rs.getDate("fecha_excepcion");
                if (fe != null) h.setFechaExcepcion(fe.toLocalDate());
                list.add(h);
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        return list;
    }

    /**
     * Obtiene horarios para un funcionario específico.
     */

    public List<HorarioProgramado> findByFuncionario(int idFuncionario) {
        List<HorarioProgramado> list = new ArrayList<>();
        String sql = "SELECT h.id_horario, h.id_funcionario, CONCAT(f.nombre,' ',f.apellido) AS nombre_funcionario, h.dia_semana, h.hora_entrada, h.hora_salida, h.es_excepcion, h.fecha_excepcion FROM HorarioProgramado h JOIN Funcionario f ON h.id_funcionario = f.id_funcionario WHERE h.id_funcionario = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idFuncionario);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                HorarioProgramado h = new HorarioProgramado();
                h.setId(rs.getInt("id_horario"));
                h.setIdFuncionario(rs.getInt("id_funcionario"));
                h.setNombreFuncionario(rs.getString("nombre_funcionario"));
                h.setDiaSemana(rs.getString("dia_semana"));
                h.setHoraEntrada(rs.getTime("hora_entrada"));
                h.setHoraSalida(rs.getTime("hora_salida"));
                h.setEsExcepcion(rs.getBoolean("es_excepcion"));
                Date fe = rs.getDate("fecha_excepcion");
                if (fe != null) h.setFechaExcepcion(fe.toLocalDate());
                list.add(h);
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        return list;
    }

    /**
     * Inserta un nuevo horario.
     */

    public boolean insert(HorarioProgramado h) {
        String sql = "INSERT INTO HorarioProgramado (id_funcionario, dia_semana, hora_entrada, hora_salida, es_excepcion, fecha_excepcion) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, h.getIdFuncionario());
            ps.setString(2, h.getDiaSemana());
            ps.setTime(3, h.getHoraEntrada());
            ps.setTime(4, h.getHoraSalida());
            ps.setBoolean(5, h.isEsExcepcion());
            if (h.getFechaExcepcion() != null) ps.setDate(6, Date.valueOf(h.getFechaExcepcion())); else ps.setNull(6, Types.DATE);
            return ps.executeUpdate() == 1;
        } catch (Exception ex) { ex.printStackTrace(); }
        return false;
    }

    /**
     * Actualiza un horario existente.
     */

    public boolean update(HorarioProgramado h) {
        String sql = "UPDATE HorarioProgramado SET id_funcionario = ?, dia_semana = ?, hora_entrada = ?, hora_salida = ?, es_excepcion = ?, fecha_excepcion = ? WHERE id_horario = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, h.getIdFuncionario());
            ps.setString(2, h.getDiaSemana());
            ps.setTime(3, h.getHoraEntrada());
            ps.setTime(4, h.getHoraSalida());
            ps.setBoolean(5, h.isEsExcepcion());
            if (h.getFechaExcepcion() != null) ps.setDate(6, Date.valueOf(h.getFechaExcepcion())); else ps.setNull(6, Types.DATE);
            ps.setInt(7, h.getId());
            return ps.executeUpdate() == 1;
        } catch (Exception ex) { ex.printStackTrace(); }
        return false;
    }

    /**
     * Elimina un horario por id.
     */

    public boolean delete(int idHorario) {
        String sql = "DELETE FROM HorarioProgramado WHERE id_horario = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idHorario);
            return ps.executeUpdate() == 1;
        } catch (Exception ex) { ex.printStackTrace(); }
        return false;
    }
}