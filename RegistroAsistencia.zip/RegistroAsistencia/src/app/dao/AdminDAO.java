package app.dao;

import app.models.Administrador;
import app.utils.DBConnection;
import app.utils.PasswordUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * AdminDAO: operaciones relacionadas con la tabla Administrador.
 */

public class AdminDAO {
    /**
     * Autentica un administrador por correo y contraseña.
     * Retorna un Administrador con sus datos si es correcto, o null si no.
     */

    public Administrador authenticate(String correo, char[] password) {
        String sql = "SELECT id_admin, nombre, apellido, correo, password_hash, rol FROM Administrador WHERE correo = ? AND activo = TRUE";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, correo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String stored = rs.getString("password_hash");
                if (PasswordUtils.verifyPassword(password, stored)) {
                    Administrador a = new Administrador();
                    a.setId(rs.getInt("id_admin"));
                    a.setNombre(rs.getString("nombre"));
                    a.setApellido(rs.getString("apellido"));
                    a.setCorreo(rs.getString("correo"));
                    a.setPasswordHash(stored);
                    a.setRol(rs.getString("rol"));
                    return a;
                }
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        return null;
    }
}