package app.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * DBConnection: administra una única conexión JDBC a la base de datos MySQL.
 * Edita la URL, usuario y contraseña según tu entorno.
 */

public class DBConnection {
    private static Connection conn;

    // === EDITAR ESTOS DATOS SEGÚN EL SERVIDOR ======= //

    private static final String URL = "jdbc:mysql://localhost:33065/empresa_asistencia2"; // Editar tu url
    private static final String USER = "root"; // Editar tu user
    private static final String PASS = ""; // Editar tu contraseña

    private static Connection connection = null;

    // ================================================ //

    /**
     * Inicializa la conexión y prueba que sea válida. Si falla, muestra mensaje y finaliza.
     */

    public static void init() {
        if (connection != null) return;

        try {
            // 👇 Carga explícita del driver (necesaria para evitar el error "No suitable driver")
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 🔌 Intenta conectar
            connection = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("Conexión a la base de datos establecida correctamente.");

        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se encontró el driver JDBC de MySQL.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error al conectar con la base de datos:");
            e.printStackTrace();
        }
    }

    /**
     * Devuelve la conexión actual. Si no existe, la inicializa.
     */

    public static Connection getConnection() {
        if (connection == null) {
            init();
        }
        return connection;
    }

    /**
     * Cierra la conexión si está abierta.
     */

    public static void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Conexión cerrada correctamente.");
            }
        } catch (SQLException e) {
            System.err.println("⚠Error al cerrar la conexión:");
            e.printStackTrace();
        }
    }
}