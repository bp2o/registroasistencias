package app.models;

/**
 * Modelo Funcionario
 */

public class Funcionario {
    private int id;
    private String nombre;
    private String apellido;
    private String correo;
    private String passwordHash; // puede contener el hash o la contrase�a en texto (DAO decidir�)
    private String telefono;
    private String departamento;
    private boolean esAdmin; // NUEVO
    private boolean activo;
    private java.sql.Date fechaContratacion;

    public Funcionario() {
        this.activo = true;
        this.esAdmin = false;
    }

    /**
     * Los getters y los setters wasd
     * */

    // ID
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    // Nombre
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Apellido
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    // Correo
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    // Obtener contraseña normal para despues hashearla con Passwordutils
    public String getPasswordHash() {
        return passwordHash;
    }
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    // https://www.youtube.com/watch?v=z-GAOm5hIlw
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    // Departamento
    public String getDepartamento() {
        return departamento;
    }
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    // Si es admin o no es admin
    public boolean isEsAdmin() {
        return esAdmin;
    }
    public void setEsAdmin(boolean esAdmin) {
        this.esAdmin = esAdmin;
    }

    // Si esta activo en la empresa o no
    public boolean isActivo() {
        return activo;
    }
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    // La fehca de contratacion
    public java.sql.Date getFechaContratacion() {
        return fechaContratacion;
    }
    public void setFechaContratacion(java.sql.Date fechaContratacion) {
        this.fechaContratacion = fechaContratacion;
    }

    // Utilitario
    public String getNombreCompleto() {
        String n = nombre == null ? "" : nombre.trim();
        String a = apellido == null ? "" : apellido.trim();
        return (n + " " + a).trim();
    }

    // Un override de... preguntale a ChatGPT
    @Override
    public String toString() {
        return "Funcionario{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", correo='" + correo + '\'' +
                ", passwordHash'" + passwordHash + '\'' +
                ", telefono='" + telefono + '\'' +
                ", departamento='" + departamento + '\'' +
                ", esAdmin=" + esAdmin +
                ", activo=" + activo +
                ", fechaContratacion=" + fechaContratacion +
                '}';
    }
}