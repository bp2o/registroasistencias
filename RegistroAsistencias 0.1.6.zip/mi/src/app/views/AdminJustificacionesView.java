package app.views;

import app.models.Justificacion;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * AdminJustificacionesView: muestra todas las justificaciones enviadas por funcionarios.
 */

public class AdminJustificacionesView extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    public JButton btnAprobar = new JButton("Aprobar");
    public JButton btnRechazar = new JButton("Rechazar");
    public JButton btnVolver = new JButton("Volver al Dashboard");

    public AdminJustificacionesView() {
        setTitle("Gestionar Justificaciones");
        setSize(900, 400);
        setLocationRelativeTo(null);


        model = new DefaultTableModel(new Object[]{"ID","Funcionario","Inicio","Fin","Motivo","Estado"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);


        JPanel buttons = new JPanel();
        buttons.add(btnAprobar); buttons.add(btnRechazar); buttons.add(btnVolver);
        add(buttons, BorderLayout.SOUTH);
    }

    // Para cargar los datos de los funcionarios
    public void loadData(List<Justificacion> justs) {
        model.setRowCount(0);
        for (Justificacion j : justs) {
            model.addRow(new Object[]{j.getId(), j.getNombreFuncionario(), j.getFechaInicio(), j.getFechaFin(), j.getMotivo(), j.getEstado()});
        }
    }

    // Se me olvido
    public int getSelectedId() {
        int r = table.getSelectedRow();
        if (r == -1) return -1;
        return (int) model.getValueAt(r, 0);
    }
}