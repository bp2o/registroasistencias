package app.views;

import javax.swing.*;
import java.awt.*;

/**
 * Vista principal para administradores.
 */

public class AdminDashboardView extends JFrame {
    public JButton btnHorarios;
    public JButton btnJustificaciones;
    public JButton btnRegistrarFuncionario;
    public JButton btnCerrarSesion;
    public JLabel lblBienvenida;

    public AdminDashboardView(String nombreAdmin) {
    	setResizable(false);
        setTitle("Dashboard - Administrador");
        setSize(520, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());

        // Panel superior
        JPanel panelTop = new JPanel();
        lblBienvenida = new JLabel("Bienvenido, " + nombreAdmin);
        lblBienvenida.setFont(new Font("Segoe UI", Font.BOLD, 18));
        panelTop.add(lblBienvenida);
        getContentPane().add(panelTop, BorderLayout.NORTH);

        // Panel central
        JPanel panelCentro = new JPanel(new GridLayout(4, 1, 10, 10));
        btnHorarios = new JButton("Gestionar Horarios");
        btnJustificaciones = new JButton("Ver Justificaciones");
        btnRegistrarFuncionario = new JButton("Registrar Funcionario");
        btnCerrarSesion = new JButton("Cerrar Sesion");

        panelCentro.add(btnHorarios);
        panelCentro.add(btnJustificaciones);
        panelCentro.add(btnRegistrarFuncionario);
        panelCentro.add(btnCerrarSesion);

        getContentPane().add(panelCentro, BorderLayout.CENTER);
    }
}
